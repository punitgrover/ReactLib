import { Database } from 'react-native-database';
import Realm from 'realm';

class School { }
School.schema = {
  name: 'School',
  primaryKey: 'id',
  properties: {
    id: 'int',
    colour: 'string?',
    email: 'string?',
    locality: 'string?',
    name: 'string?',
    siteid: 'int',
    street: 'string?',
    telephone: 'string?',
    town: 'string?',
    thumbnail: 'string?',
    website: 'string?',
    postcode: 'string?',
    newscategories: 'string?',
    eventscategories: 'string?',
    albumscategories: 'string?'
  },
};

class User { }
User.schema = {
  name: 'User',
  primaryKey: 'id',
  properties: {
    id: 'int',
    username: 'string',
    auth_token: 'string',
    break_time: { type: 'int', default: 0 },
    isBreakStop: { type: 'bool', default: true },
    email: 'string',
    name: 'string',
    login_time: 'string?',
    is_trainee: 'bool',
    status: 'bool',
  },
};
class Calendar { }
Calendar.schema = {
  name: 'Calendar',
  // primaryKey: 'id',
  properties: {
    siteid: 'int',
    id: 'int',
    eventid: 'string',    
   },
};

class ShowNavigator { }
ShowNavigator.schema = {
  name: 'ShowNavigator',
  // primaryKey: 'id',
  properties: {
    isShow: 'bool',
    
   },
};

class Category { }
Category.schema = {
  name: 'Category',
  // primaryKey: 'id',
  properties: {
    siteid: 'string',
    type: 'string',
    
   },
};

class Boxes { }
Boxes.schema = {
  name: 'Boxes',
  primaryKey: 'id',
  properties: {
    id: 'int',
    name: 'string',
  },
};


class OrderBoxes { }
OrderBoxes.schema = {
  name: 'OrderBoxes',
  properties: {
    boxId: 'int',
    order_no: 'string',
    boxNumber: 'string',
    boxName: 'string'
  },
};


class Barcodes { }
Barcodes.schema = {
  name: 'Barcodes',
  properties: {
    barcode: 'string?',
    scanned: 'bool?'
  },
};

class Order { }
Order.schema = {
  name: 'Order',
  primaryKey: 'id',
  properties: {
    order_id: 'int',
    order_no: 'string',
    customer_name: 'string',
    order_status: 'int',
    id: 'int',
    product_category_id: 'int',
    name: 'string',
    sku: 'string',
    barcode: 'string?',
    barcodes: { type: 'list', objectType: 'Barcodes' },
    master_barcode: 'string?',
    minimum: 'int?',
    multiples: 'int?',
    base_price: 'float?',
    vendor_id: 'int',
    description: 'string?',
    status: 'bool',
    price_count: 'int?',
    image: 'string',
    type: 'string',
    acc: 'string?',
    current_stock: 'int',
    shortage: 'int?',
    location: 'string?',
    location_barcode: 'string?',
    isLocationScanned: { type: 'bool', default: false },
    zone: 'string?',
    quantity: 'int?',
    weight: 'float?',
    rrp_price: 'float?',
    warehouse_id: 'int',
    modified: 'string?',
    isOrderComplete: { type: 'bool', default: false },
  },
};

class OrderPicked { }
OrderPicked.schema = {
  name: 'OrderPicked',
  primaryKey: 'order_id',
  properties: {
    order_id: 'int',
    order_no: 'string',
    customer_name: 'string',
    order_status: 'bool',
    pick_time: { type: 'int', default: 0 },
    isPickContinue: { type: 'bool', default: false },
  },
};

const schema = { schema: [School, User, Boxes, OrderBoxes, Order, OrderPicked, Barcodes, Calendar, ShowNavigator, Category], schemaVersion: 1 };
const database = new Database(schema);
export const realm = new Realm(schema);

export const saveTODB = (className, props, callback) => {
  
  try {
    database.write(() => { database.create(className, props); });
    callback(true, 'saved sucessfuly');
  } catch (error) {
    //  debugger
    callback(false, JSON.stringify(error));
  }
};

export const fetchDataWithIdFromDB = (className, query, callback) => {
  // debugger;
  try {
    callback(true, database.objects(className).filtered(query));
  } catch (error) {
    // debugger;
    callback(false, []);
  }
};

export const fetchDataWithIdWithANDFromDB = (className, query, andQuery, callback) => {
  // debugger;
  try {
    callback(true, database.objects(className).filtered(query).filtered(andQuery));
  } catch (error) {
    // debugger;
    callback(false, []);
  }
};

export const fetchListFromDB = (className, callback) => {
  try {
    callback(true, database.objects(className));
  } catch (error) {
    callback(false, []);
  }
};

export const deleteFromDB = (className, props, callback) => {
  try {
    database.delete(className, props);
    callback(true);
  } catch (error) {
    //  debugger;
    callback(false);
  }
};

