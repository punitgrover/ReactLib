import React from 'react';
import { View, Text, Image } from 'react-native';
import { responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import ElevatedView from 'react-native-elevated-view';
import ImageLoad from 'react-native-image-placeholder';
import * as Database from '../../database';

const trans = require('../../Images/img-overlay.png');
const createReactClass = require('create-react-class');

const AlbumsRow = createReactClass({
    renderImage() {
        if (this.props.rowData.siteid !== undefined) {
            Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.siteid + '"', (flag, data) => {
                if (flag) {
                    if (data.length > 0) {
                        this.props.rowData.colour = data[0].colour;
                        this.props.rowData.name = data[0].name;
                        this.props.rowData.website = data[0].website;
                    } else {
                        this.props.rowData.colour = 'yellow';
                    }
                } else {
                    this.props.rowData.colour = 'yellow';
                }
            });
        }
        const str = this.props.rowData.website + this.props.rowData.thumbnail;
        const url = str.replace('  ', '%20');
        console.log(str);
        return (
            <ImageLoad loadingStyle={{ size: 'small', color: '#13AAEB' }} source={{ uri: url }} style={{ flex: 1, alignSelf: 'stretch' }} />
        );
    },
    render() {
        return (
            <ElevatedView
                elevation={3}
                style={{
                    flex: 1, height: responsiveWidth(50), backgroundColor: 'white', marginTop: 8, marginLeft: 5, marginRight: 5,
                    shadowOffset: { width: 1.5, height: 1.5 },
                    shadowColor: 'gray',
                    shadowOpacity: 1.0,
                }}>
                {this.renderImage()}
                <Image source={trans} style={{ height: responsiveWidth(50), position: 'absolute', backgroundColor: 'transparent', flex: 1, marginRight: 10, resizeMode: 'cover' }} />
                <View style={{ flex: 1, backgroundColor: 'transparent', position: 'absolute', bottom: 0, left: 0, right: 0 }} >
                    <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', flex: 1, marginLeft: 20, color: 'white', fontSize: responsiveFontSize(2.8), fontWeight: '600' }}>{this.props.rowData.title}</Text>
                    <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', flex: 1, marginLeft: 20, color: 'white', fontSize: responsiveFontSize(1.8), fontWeight: '200', marginBottom: 5 }}>{this.props.rowData.name}</Text>
                </View>
            </ElevatedView>
        );
    }
});

export default AlbumsRow;
