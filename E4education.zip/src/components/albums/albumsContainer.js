import React, { Component } from 'react';
import { View, TouchableHighlight, FlatList } from 'react-native';
import { responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { RNProgressHUD } from 'react-native-simplest-hud';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import { NoSalonView } from '../common';
import logo from '../../Images/iTunesArtwork.png';
import { fetchSchoolAlbums } from '../../services/school';
import AlbumsRow from './albumsrow';
import SharedManager from '../../common/sharedmanager';
import * as Database from '../../database';

class AlbumsContainer extends Component {

  constructor(props) {
    super(props);
    this.arrAlbums = [];
    this.state = {
      isLoading: true,
      refreshing: false,
      data: []
    };
    this.onBackButtonAction = this.onBackButtonAction.bind(this);
    this.onSideMenuPress = this.onSideMenuPress.bind(this);
  }
  componentWillMount() {
    this.getData();
  }
  getData() {
    this.setState({
        isLoading: true,
    });
    if (this.props.isAll === true) {
      const arrSchool = [];
      Database.fetchListFromDB('School', (flag, data) => {
        if (flag) {
          data.map((item) => {
            arrSchool.push({ siteid: item.siteid, categories: item.albumscategories, lastupdated: 0 });
          });
        }
      });
      this.callAlbumApi({ device: SharedManager.getInstance().getDeviceID(), schools: arrSchool });
    } else {
      const category = '';
      Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.data.siteid + '"', (flag, object) => {
        if (flag) {
          category = object[0].albumscategories;
        }
      });
      this.callAlbumApi({ device: SharedManager.getInstance().getDeviceID(), schools: [{ siteid: this.props.data.siteid, categories: category, lastupdated: 0 }] });
    }
  }

  callAlbumApi(postValue) {
    fetchSchoolAlbums(postValue, (flag, response, msg) => {
      if (flag) {
        SharedManager.getInstance().setDeviceID(response.api_deviceid);
        this.arrAlbums = [];
        response.schools.map((albums) => {
          this.arrAlbums = this.arrAlbums.concat(albums.albums);
        });
        this.arrAlbums = this.arrAlbums.filter(function (item) {
          return item.action !== 'remove';
        });

      } else {
        Common.showAlertWithDefaultTitle(msg);
      }
      this.updateSchoolList();
    });
  }
  updateSchoolList() {
    this.setState({
      isLoading: false,
      refreshing: false,
      data: this.arrAlbums
    });
  }
  onSideMenuPress() {
    Actions.main();
  }
  onBackButtonAction() {
    Actions.pop();
  }
  onPressRow(rowID, rowData) {
    if (rowData.images !== undefined) {
      Actions.albumslist({ data: rowData });
    } else {
      Common.showAlertWithDefaultTitle('Images not found');
    }
  }
  onRefresh() {
    this.setState({
      refreshing: true,
      isLoading: true,
    });
    this.getData();
  }
  renderRow(rowData, sectionID, rowID) {
    return (
      <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => this.onPressRow(rowID, rowData)}>
        <View style={styles.style_row_view}>
          <AlbumsRow {...rowData} key={rowData.id} rowData={rowData} />
        </View>
      </TouchableHighlight>
    );
  }
  checkData() {
    if (this.arrAlbums.length === 0 && !this.state.isLoading) {
      return (
        <NoSalonView
          imageName={logo}
          message='No Record Found'
          onPressRefresh={() => this.getData()}
        />
      );
    } else {
      return (
        <FlatList
          ref={(list) => { this.flatListRef = list; }}
          onRefresh={() => this.onRefresh()}
          refreshing={this.state.refreshing}
          removeClippedSubviews={false}
          legacyImplementation
          viewabilityThreshold={0}
          initialListSize={1000}
          //    data={this.state.stories}
          keyExtractor={(item, index) => item.id}
          data={this.state.data}
          extraData={this.state}
          renderItem={({ item }) => (
            this.renderRow(item)
          )}
        />
      );
    }
  }

  render() {
    return (
      <View style={{ flex: 1, backgroundColor: '#F1F5F8', width: responsiveScreenWidth(100) }}>
        {this.checkData()}
        <RNProgressHUD
          isVisible={this.state.isLoading}
          color='#434c54'
          label='Loading'
          isActivityIndicator
        />
      </View>
    );
  }

}

const styles = {

  style_row_view: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#F1F5F8',
  }
};
export default AlbumsContainer;
