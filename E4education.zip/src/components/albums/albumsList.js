import React, { Component } from 'react';
import { StyleSheet, View, TouchableHighlight } from 'react-native';
import GridView from 'react-native-super-grid';
import { responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import GridRow from './gridrow';
import * as Database from '../../database';

class Albums extends Component {

  constructor(props) {
    super(props);
    const json = JSON.parse(this.props.data.images);
    this.arrAlbums = Object.keys(json).map(function (key) { return json[key]; });
    if (this.props.data.siteid !== undefined) {
      Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.data.siteid + '"', (flag, object) => {
        if (flag) {
          if (object.length > 0) {
            this.props.data.name = object[0].name;
            this.props.data.website = object[0].website;
          }
        }
      });
    }

    var index = 0;
    this.arrAlbums.map((item) => {
      item.name = this.props.data.name;
      item.comoleteURL = `${this.props.data.website}${item.thumbnail}`.replace('  ', '%20');
      item.index = index;
      index = index + 1;
      return item;
    });
    this.onPressRow = this.onPressRow.bind(this);
  }
  onPressRow(rowID, sectionID, rowData) {
    Actions.fullImage({ strurl: this.props.data.website, arr: this.arrAlbums, index: rowData.index, title: this.props.data.title });
  }
  renderRow(rowData, sectionID, rowID) {
    return (
      <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => this.onPressRow(rowID, sectionID, rowData)}>
        <View style={styles.style_row_view}>
          <GridRow {...rowData} key={rowData.id} rowData={rowData} />
        </View>
      </TouchableHighlight>
    );
  }
  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>
        {Common.addNavTitleWithback(this.props.data.title)}
        <GridView
          itemDimension={responsiveScreenWidth(25)}
          items={this.arrAlbums}
          style={styles.gridView}
          renderItem={this.renderRow.bind(this)}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  gridView: {
    paddingTop: 10,
    flex: 1,
  },
 });

export default Albums;