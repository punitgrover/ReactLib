import React, { Component } from 'react';
import { View } from 'react-native';
import { responsiveFontSize } from 'react-native-responsive-dimensions';
import { IndicatorViewPager, PagerTitleIndicator } from 'rn-viewpager';
import { EventRegister } from 'react-native-event-listeners';
import * as Common from '../../common';
import AlbumsContainer from './albumsContainer';
import * as Database from '../../database';

class Albums extends Component {

    constructor(props) {
        super(props);
        this.state = {
            arrSchool: []
        };
    }
    componentWillMount() {
        this.getData();
        this.listener = EventRegister.addEventListener('updateFilter', (arrData) => {
            this.setState({ arrSchool: [] });
            this.setState({ arrSchool: arrData });
        });
    }

    getData() {
        Database.fetchListFromDB('School', (flag, data) => {
            if (flag) {
                this.setState({ arrSchool: data });
            }
        });
    }

    _renderTitleIndicator() {

        var title = ['All'];
        this.state.arrSchool.map((data) => {
            title.push(data.name);
        });
        return <PagerTitleIndicator titles={title}
            itemTextStyle={{ color: '#84A0AE', fontSize: responsiveFontSize(2.3), fontStyle: 'normal', fontFamily: 'Proxima Nova', }}
            selectedItemTextStyle={{ color: '#2D2D2D', fontSize: responsiveFontSize(2.3), fontStyle: 'normal', fontFamily: 'Proxima Nova', }}
            selectedBorderStyle={{ backgroundColor: '#2D2D2D', height: 2 }}
            trackScroll={true}

        />;
    }
    renderNewsListView() {
        return this.state.arrSchool.map((rowData) => {
            return (
                <View style={{ flex: 1, backgroundColor: 'pink' }}>
                    <AlbumsContainer isAll={false} data={rowData} />
                </View>
            );
        });
    }
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'white' }}>
                {Common.addNavTitleWithback('Albums')}
                <View style={{ flex: 1, backgroundColor: 'transparent' }}>
                    <IndicatorViewPager
                        style={{ flex: 1, backgroundColor: 'transparent' }}
                        indicator={this._renderTitleIndicator()}
                    >
                        <View style={{ flex: 1, backgroundColor: 'pink' }}>
                            <AlbumsContainer isAll />
                        </View>
                        {this.renderNewsListView()}
                    </IndicatorViewPager>
                </View>

            </View>
        );
    }

}
export default Albums;
