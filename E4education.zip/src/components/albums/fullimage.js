import React, { Component } from 'react';
import { View } from 'react-native';
import Gallery from 'react-native-image-gallery';
import * as Common from '../../common';

class FullImage extends Component {

    constructor(props) {
        super(props);
        this.arrmedia = []
        this.arrImage = [];
        props.arr.map((list) => {
            this.arrImage.push({ source: { uri: `${props.strurl}${list.image}`.replace('  ', '%20') } });
        });
    }
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'white' }}>
                {Common.addNavTitleWithback(this.props.title)}
                <View style={{ flex: 1, backgroundColor: 'transparent' }}>
                    <Gallery
                        style={{ flex: 1, backgroundColor: 'black', alignSelf: 'stretch' }}
                        initialPage={parseInt(this.props.index)}
                        images={this.arrImage}
                    />
                </View>
            </View>
        );
    }

}
export default FullImage;
