import React from 'react';
import { View, StyleSheet } from 'react-native';
import { responsiveScreenWidth } from 'react-native-responsive-dimensions';
import ImageLoad from 'react-native-image-placeholder';

const createReactClass = require('create-react-class');

const GridRow = createReactClass({
  render() {
    const str = this.props.rowData.comoleteURL;
    const url = str.replace('  ', '%20');
    return (
      <View style={{ flex: 1 }} >
        <ImageLoad loadingStyle={{ size: 'small', color: '#13AAEB' }} source={{ uri: url }} style={[styles.itemContainer, { alignSelf: 'stretch' }]} />
      </View>
    );
  }
});
const styles = StyleSheet.create({
  gridView: {
    paddingTop: 10,
    flex: 1,
  },
  itemContainer: {
    justifyContent: 'flex-end',
    borderRadius: 0,
    padding: 0,
    height: responsiveScreenWidth(25),
  },
});

export default GridRow;

