import React, { Component } from 'react';
import { View, TouchableHighlight, SectionList } from 'react-native';
import { responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { RNProgressHUD } from 'react-native-simplest-hud';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import { NoSalonView } from '../common';
import logo from '../../Images/iTunesArtwork.png';
import { fetchSchoolEvent } from '../../services/school';
import EventRow from './eventrow';
import EventSection from './eventsection';
import SharedManager from '../../common/sharedmanager';

class EventsList extends Component {

  constructor(props) {
    super(props);
    this.arrEvents = [];
    this.state = {
      isLoading: true,
      refreshing: false,
      data: []
    };
  }

  componentWillMount() {
    this.getData();
  }
  componentWillReceiveProps() {
    this.getData();
  }

  getData() {
    this.setState({
          isLoading: true,
    });
    if (this.props.isAll === true) {
      const arrSchool = [];
      var arrData = [];

      try {
        arrData = Array.prototype.slice.apply(this.props.data);
        arrData.map((item) => {
          arrSchool.push({ siteid: item.siteid, categories: item.eventscategories, lastupdated: 0 });
        });
        this.callEventApi({ device: SharedManager.getInstance().getDeviceID(), schools: arrSchool });
      } catch (error) { }
    } else {
      try {
        this.callEventApi({ device: SharedManager.getInstance().getDeviceID(), schools: [{ siteid: this.props.data.siteid, categories: this.props.data.eventscategories, lastupdated: 0 }] });
      } catch (error) { }
    }
  }

  callEventApi(postValue) {
    fetchSchoolEvent(postValue, (flag, response, msg) => {
      const dateTime = +new Date();
      const timestamp = Math.floor(dateTime / 1000);
      if (flag) {
        SharedManager.getInstance().setDeviceID(response.api_deviceid);
        this.events = [];
        this.arrEvents = [];
        this.sectionIds = [];
        this.events = [];
        response.schools.map((events) => {
          this.events = this.events.concat(events.events);
        });
        this.events = this.events.filter(function (item) {
          return item.action !== 'remove';
        });
        const resultArray = this.events.filter(item => item.date >= timestamp);
        this.events = resultArray;
        const arr = this.bubbleSortDates(this.events);

        this.events = [];
        this.events = arr;

        const dates = [];
        for (const obj of this.events) {
          dates.push(obj.date);
        }
        const uniqueDates = Array.from(new Set(dates));

        for (const obj of uniqueDates) {
          const result = this.events.filter(item => item.date === obj);
          this.arrEvents.push({ title: obj, data: result });
        }
        this.updateSchoolList();
      }
      else {
        Common.showAlertWithDefaultTitle(msg);
      }
      this.updateSchoolList();
    });
  }
  bubbleSortDates = (arr) => {
    for (var i = arr.length - 1; i >= 0; i--) {
      for (var j = 1; j <= i; j++) {
        if (new Date(arr[j - 1].date) > new Date(arr[j].date)) {
          var temp = arr[j - 1];
          arr[j - 1] = arr[j];
          arr[j] = temp;
        }
      }
    }
    return arr;
  };
  updateSchoolList() {
    this.setState({
      isLoading: false,
      refreshing: false,
      data: this.arrEvents
    });
  }
  onRefresh() {
    this.setState({
      refreshing: true,
      isLoading: true,
    });
    this.getData();
  }
  renderListRowView(rowData) {
    return (
      <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => Actions.eventdetails({ data: rowData })}>
        <View style={styles.style_row_view}>
          <EventRow rowData={rowData} />
        </View>
      </TouchableHighlight>
    );
  }

  renderSectionHeader(rowData) {
    return (
      <View style={{ flex: 1, backgroundColor: '#F1F5F8' }}>
        <EventSection rowData={rowData} />
      </View>
    );
  }
  checkData() {
    if (this.arrEvents.length === 0 && !this.state.isLoading) {
      return (
        <NoSalonView
          imageName={logo}
          message='No Record Found'
          onPressRefresh={() => this.getData()}
        />
      );
    } else {
      return (
        <SectionList
          sections={this.state.data}
          renderSectionHeader={({ section }) => this.renderSectionHeader(section.title)}
          renderItem={({ item }) => this.renderListRowView(item)}
          style={{ flex: 1 }}
          onRefresh={() => this.onRefresh()}
          refreshing={this.state.refreshing}
          removeClippedSubviews={false}
        />
      );
    }
  }
  render() {
    return (
      <View style={{ flex: 1, width: responsiveScreenWidth(100) }}>
        {this.checkData()}
        <RNProgressHUD
          isVisible={this.state.isLoading}
          color='#434c54'
          label='Loading'
          isActivityIndicator
        />
      </View>
    );
  }
}

const styles = {

  style_row_view: {
    flex: 1,
    backgroundColor: '#F1F5F8'

  },
};

export default EventsList;
