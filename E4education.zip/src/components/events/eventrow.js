import React from 'react';
import { View, Text, Image } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import * as Database from '../../database';
import ElevatedView from 'react-native-elevated-view';

const createReactClass = require('create-react-class');
const timer = require('../../Images/time.png');
const moment = require('moment');

const EventRow = createReactClass({
    drawline() {
        if (this.props.rowData.siteid !== undefined) {
            Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.rowData.siteid + '"', (flag, data) => {
                if (flag) {
                    if (data.length > 0) {
                        this.props.rowData.colour = data[0].colour;
                        this.props.rowData.name = data[0].name;
                        this.props.rowData.website = data[0].website;
                    }
                }
            });
        }
        return (
            <View style={{ height: null, width: 8, backgroundColor: this.props.rowData.colour }} />
        );
    },
    getStartTime() {
        
        if (this.props.rowData.starttime !== undefined && this.props.rowData.starttime !== ''){
            return(
               moment(this.props.rowData.starttime, 'hmm').format('HH:mm')
            );
        }else{
           return(
               '--'
            );
        }
    },
    getEndTime() { 
        
         if (this.props.rowData.endtime !== undefined && this.props.rowData.endtime !== ''){
             return(
                moment(this.props.rowData.endtime, 'hmm').format('HH:mm')
             );
         }else{
            return(
                '--'
             );
         }
    },
    renderTime() {
        if (this.props.rowData.starttime.length > 0) {
            return (
                <View style={{ flex: 1.5, marginLeft: 5, marginRight: 5, marginTop: 15, backgroundColor: 'transparent', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }} >
                    <Image source={timer} style={{ width: responsiveScreenWidth(3), height: responsiveScreenWidth(3), backgroundColor: 'transparent', resizeMode: 'contain' }} />
                    <Text style={{ color: '#B3C3D0', fontStyle: 'normal', fontFamily: 'Proxima Nova', fontSize: responsiveFontSize(1.5), fontWeight: '500', marginLeft: 5 }} >{this.getStartTime()} : {this.getEndTime()} </Text>
                </View>
            );
        }
    },
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'transparent', marginTop: 0, marginLeft: 10, marginRight: 10 }}>
                <ElevatedView
                    elevation={3}
                    style={{
                        flex: 1,
                        shadowOffset: { width: 1.5, height: 1.5 },
                        shadowColor: 'gray',
                        shadowOpacity: 1.0,
                        backgroundColor: 'white',
                    }}>
                    <View style={{ flex: 1, width: null, backgroundColor: 'transparent', flexDirection: 'row' }}>
                        {this.drawline()}
                        <View style={{ flex: 1, backgroundColor: 'white' }} >
                            <View style={{ flex: 1, backgroundColor: 'white', flexDirection: 'row' }} >
                                <Text style={{ flex: 3, fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#444A4E', fontSize: responsiveFontSize(2.2), fontWeight: '500', marginLeft: responsiveScreenWidth(3.0), marginTop: 15 }} >{this.props.rowData.title}</Text>
                                {this.renderTime()}
                            </View>
                            <Text style={{ flex: 1, fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#B3C3D0', fontSize: responsiveFontSize(1.8), fontWeight: '500', marginLeft: responsiveScreenWidth(3.0), marginTop: 5, marginBottom: 15 }} >{this.props.rowData.name}</Text>
                        </View>
                    </View>
                </ElevatedView>
                <View style={{ height: 25, width: 2, backgroundColor: '#95ACBB', marginBottom: 0, marginTop: 0, marginLeft: 3 }} />
            </View>
        );
    }
});

export default EventRow;
