import React from 'react';
import { View, Text } from 'react-native';
import { responsiveWidth, responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';

const createReactClass = require('create-react-class');
const moment = require('moment');

const EventSection = createReactClass({
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'transparent', marginTop: 0, marginLeft: 10, marginRight: 10, marginBottom: 0 }}>
                <View style={{ flex: 1 }}>
                    <View style={{ flex: 1, backgroundColor: 'transparent', flexDirection: 'row', }}>
                        <View style={{ height: null, marginBottom: 0, marginTop: 0, backgroundColor: 'transparent', width: 8, justifyContent: 'center', alignItems: 'center' }}>
                            <View style={{ flex: 1, width: 2, backgroundColor: '#95ACBB' }} />
                            <View style={{ flex: 1, backgroundColor: '#95ACBB', height: responsiveWidth(2), width: responsiveWidth(2), borderRadius: responsiveWidth(1), position: 'absolute' }} />
                        </View>
                        <Text style={{ flex: 3, fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#363C41', fontSize: responsiveFontSize(3.5), fontWeight: '700', marginLeft: responsiveScreenWidth(4), marginTop: 20, marginBottom: 20 }} >{moment.unix(this.props.rowData).format("dddd DD MMM").toUpperCase()}</Text>
                    </View>

                </View>
            </View>
        );
    }
});

export default EventSection;
