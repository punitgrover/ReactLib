import React, { Component } from 'react';
import { View, Text, TouchableHighlight, Image, ScrollView, BackHandler } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { Actions } from 'react-native-router-flux';
import RNCalendarEvents from 'react-native-calendar-events';
import * as Common from '../../common';
import * as Database from '../../database';

const striptags = require('striptags');
const moment = require('moment');
const timer = require('../../Images/time.png');

class EventDetails extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isSync: false,
        };
    }

    getStartTime() {        
        if (this.props.data.starttime !== undefined && this.props.data.starttime !== ''){
            return(
               moment(this.props.data.starttime, 'hmm').format('HH:mm')
            );
        }else{
           return(
               '--'
            );
        }
    }
    getEndTime() {         
         if (this.props.data.endtime !== undefined && this.props.data.endtime !== ''){
             return(
                moment(this.props.data.endtime, 'hmm').format('HH:mm')
             );
         }else{
            return(
                '--'
             );
         }
    }
    componentWillMount() {
        BackHandler.addEventListener('hardwareBackPress', () => {
            Actions.pop();
            return true;
        });

        Database.fetchDataWithIdWithANDFromDB('Calendar', 'siteid = "' + this.props.data.siteid + '"', 'id = "' + this.props.data.id + '"', (flag, data) => {
            if (flag) {
                if (data.length > 0) {
                    this.setState({ isSync: true });
                }
            } else {
                this.setState({ isSync: false });
            }
        });
    }

    syncToCalender() {
        const date = moment.unix(this.props.data.date).format('DD MMM YYYY');
        const startTime = moment(this.props.data.starttime, 'hmm').format('hh:mm a');
        const endTime = moment(this.props.data.endtime, 'hmm').format('hh:mm a');
        const startDate = new Date(`${date}, ${startTime}`);
        const endDate = new Date(`${date}, ${endTime}`);
        RNCalendarEvents.authorizationStatus()
            .then(status => {
                if (status === 'authorized') {
                    RNCalendarEvents.saveEvent(this.props.data.title, {
                        location: this.props.data.name,
                        notes: striptags(this.props.data.desc),
                        startDate: startDate.toISOString(),
                        endDate: endDate.toISOString()
                    })
                        .then(eventId => {
                            const post = { siteid: this.props.data.siteid, id: this.props.data.id, eventid: `${eventId}` };
                            Database.saveTODB('Calendar', post, (flag, message) => {
                                if (flag) {
                                    this.setState({ isSync: true });
                                } else {
                                    this.setState({ isSync: false });
                                }
                            });
                        })
                        .catch(error => {
                            Common.showAlertWithDefaultTitle(JSON.stringify(error));
                            this.setState({ isSync: false });
                        });
                } else {
                    Common.showAlertWithDefaultTitle('Please allow calandar access for sync event');
                    this.setState({ isSync: false });
                }
            })
            .catch(error => {
            });
    }

    deleteSchoolFromDB(object) {
        try {
            Database.realm.write(() => {
                Database.realm.delete(object);
                this.updateSchoolList();
            });

        } catch (error) {
            Common.showAlertWithDefaultTitle(JSON.stringify(error));
        }
    }
    deleteEventFromDB(data) {
        try {
            Database.realm.write(() => {
                Database.realm.delete(data);
            });
        } catch (error) {
        }
    }

    removeFromCalender() {
        Database.fetchDataWithIdWithANDFromDB('Calendar', 'siteid = "' + this.props.data.siteid + '"', 'id = "' + this.props.data.id + '"', (flag, data) => {
            if (flag) {
                if (data.length > 0) {
                    RNCalendarEvents.removeEvent(data[0].eventid)
                        .then(success => {
                            this.setState({ isSync: false });
                            this.deleteEventFromDB(data[0]);
                        })
                        .catch(error => {
                        });
                }
            } else {
                this.setState({ isSync: false });
            }
        });
    }

    renderTime() {
        if (this.props.data.starttime.length > 0) {
            return (
                <View style={{ flex: 1, marginLeft: 5, marginRight: 5, backgroundColor: 'transparent', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }} >
                    <Image source={timer} style={{ width: responsiveScreenWidth(4), height: responsiveScreenWidth(4), backgroundColor: 'transparent', resizeMode: 'contain' }} />
                    <Text style={{ marginLeft: 5, fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#B3C3D0', fontSize: responsiveFontSize(1.8), fontWeight: '400' }} >{this.getStartTime()} : {this.getEndTime()}</Text>
                </View>
            );
        } else {
        }
    }
    renderCalenderButton() {
        if (this.props.data.starttime.length > 0 && this.props.data.endtime.length > 0) {
            if (this.state.isSync === true) {
                return (
                    <View style={{ width: null, backgroundColor: 'transparent', height: responsiveScreenWidth(15), justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ flex: 1 }} onPress={() => this.removeFromCalender()}>
                            <View style={{ marginTop: responsiveScreenWidth(2.5), marginBottom: responsiveScreenWidth(2.5), flex: 1, borderRadius: responsiveScreenWidth(5), backgroundColor: '#95ACBC', flexDirection: 'row', alignItems: 'center' }}>
                                <Image source={require('../../Images/add_to_calendar.png')} style={{ marginLeft: 10, backgroundColor: 'transparent', width: responsiveScreenWidth(8), height: responsiveScreenWidth(5), resizeMode: 'contain' }} />
                                <Text style={{ marginLeft: 5, fontStyle: 'normal', fontFamily: 'Proxima Nova', backgroundColor: 'transparent', color: 'white', fontSize: responsiveFontSize(1.8), fontWeight: '500', marginRight: 20 }} >REMOVE FROM</Text>
                            </View>
                        </TouchableHighlight>

                    </View>
                );
            } else {
                return (
                    <View style={{ width: null, backgroundColor: 'transparent', height: responsiveScreenWidth(15), justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ flex: 1 }} onPress={() => this.syncToCalender()}>
                            <View style={{ marginTop: responsiveScreenWidth(2.5), marginBottom: responsiveScreenWidth(2.5), flex: 1, borderRadius: responsiveScreenWidth(5), backgroundColor: '#95ACBC', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                <Image source={require('../../Images/add_to_calendar.png')} style={{ marginLeft: 10, backgroundColor: 'transparent', width: responsiveScreenWidth(8), height: responsiveScreenWidth(5), resizeMode: 'contain' }} />
                                <Text style={{ marginLeft: 5, fontStyle: 'normal', fontFamily: 'Proxima Nova', alignSelf: 'center', backgroundColor: 'transparent', color: 'white', fontSize: responsiveFontSize(1.8), fontWeight: '500', marginRight: 20 }} >ADD TO CALENDAR</Text>
                            </View>
                        </TouchableHighlight>

                    </View>
                );
            }
        }
    }
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'white' }}>
                {Common.addNavTitleWithback('Events')}
                <View style={{ flex: 1, backgroundColor: 'transparent' }} >
                    <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', backgroundColor: 'transparent', color: '#3A4045', fontSize: responsiveFontSize(3), marginTop: 20, marginLeft: responsiveScreenWidth(6), marginRight: responsiveScreenWidth(6), marginBottom: 5, fontWeight: '500' }}>{this.props.data.title}</Text>
                    <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#B3C3D0', fontSize: responsiveFontSize(1.7), fontWeight: '400', marginLeft: responsiveScreenWidth(6), marginRight: responsiveScreenWidth(6) }} >{this.props.data.name}</Text>
                    <View style={{ width: null, height: 1, backgroundColor: '#EDF1F1', marginLeft: responsiveScreenWidth(3), marginRight: responsiveScreenWidth(3), marginTop: 15, marginBottom: 15 }} />
                    <View style={{ flexDirection: 'row', marginLeft: responsiveScreenWidth(6), marginRight: responsiveScreenWidth(6), marginBottom: 15, backgroundColor: 'transparent' }}>
                        <Text style={{ flex: 2, fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#3A4045', fontSize: responsiveFontSize(2), fontWeight: '600' }}>{moment.unix(this.props.data.date).format("dddd DD MMM").toUpperCase()}</Text>
                        {this.renderTime()}
                    </View>
                    <View style={{ width: null, height: 1, backgroundColor: '#EDF1F1', marginLeft: responsiveScreenWidth(3), marginRight: responsiveScreenWidth(3) }} />
                    <ScrollView contentContainerStyle={{ paddingVertical: 20 }}>
                        <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#2D2F31', fontSize: responsiveFontSize(1.7), fontWeight: '400', marginLeft: responsiveScreenWidth(6), marginRight: responsiveScreenWidth(6), }} >
                            {striptags(this.props.data.desc)}
                        </Text>
                    </ScrollView>
                    {this.renderCalenderButton()}
                </View>
            </View>
        );
    }

}

export default EventDetails;
