import React from 'react';
import { View, Text } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import * as Database from '../../database';
import ImageLoad from 'react-native-image-placeholder';
import ElevatedView from 'react-native-elevated-view';

var createReactClass = require('create-react-class');
var moment = require('moment');

var NewsRow = createReactClass({
 
    renderImage() {
        // const str = `${this.props.rowData.website}${this.props.rowData.thumbnail}`;
        const str = this.props.rowData.website + this.props.rowData.thumbnail;
        const url = str.replace('  ', '%20');
       return (
            <ImageLoad loadingStyle={{ size: 'small', color: '#13AAEB' }} source={{ uri: url }} style={{ flex: 1, backgroundColor: 'transparent', resizeMode: 'cover' }} />
        );
    },
    renderBlankView() {
        return (
            <View style={{ flex: 1, backgroundColor: 'transparent' }} />
        );
    },

    drowLine() {
        if (this.props.rowData.siteid !== undefined) {
            Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.siteid + '"', (flag, data) => {
                if (flag) {
                    if (data.length > 0) {
                        this.props.rowData.colour = data[0].colour;
                        this.props.rowData.name = data[0].name;
                        this.props.rowData.website = data[0].website;
                    } else {
                        this.props.rowData.colour = 'yellow';
                    }
                } else {
                    this.props.rowData.colour = 'yellow';
                }
            });
        } else {
            this.props.rowData.colour = 'yellow';
        }
        return (
            <View style={{ height: null, width: 4, backgroundColor: this.props.rowData.colour }} />
        );
    },

    render: function () {
        return (
            
            // <View  style={{ flex: 1, backgroundColor: 'white', marginTop: 5, marginLeft: 5, marginRight: 5,  }} >
            <ElevatedView 
           elevation={3}
            style={{ flex: 1, backgroundColor: 'white', marginTop: 10,
            // elevation: 1, 
            shadowOffset: { width: 1.5, height: 1.5 },
            shadowColor: '#d3d3d3',
            shadowOpacity: 1.0,
            marginBottom: 10,
            marginLeft: 10, 
            marginRight: 10,
            // marginBottom: 5,
            }}>
                <View style={{ flex: 1, }}>
                    <View style={{ flex: 1, width: null, backgroundColor: 'transparent', flexDirection: 'row' }}>
                        {this.drowLine()}
                        <View style={{ flex: 1, height: responsiveScreenWidth(35.0), width: null, backgroundColor: 'white', justifyContent: 'center', alignContent: 'center' }} >
                            <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#97A2A8', fontSize: responsiveFontSize(2), marginLeft: responsiveScreenWidth(3.0), marginTop: 5 }} >{moment.unix(this.props.rowData.date).format("D MMM YYYY").toUpperCase()}</Text>
                            <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#444A4E', fontSize: responsiveFontSize(2.2), fontWeight: '500', marginLeft: responsiveScreenWidth(3.0), marginTop: 15, }} numberOfLines={3} >{this.props.title}</Text>
                        </View>
                        <View style={{ width: responsiveScreenWidth(35.0), height: responsiveScreenWidth(35.0), backgroundColor: this.props.rowData.colour }} >
                            {this.props.rowData.thumbnail !== null ? this.renderImage() : this.renderBlankView()}
                        </View>
                    </View>
                    <View style={{ flex: 1, backgroundColor: 'white' }}>
                        <View style={{ flex: 1, height: 1, backgroundColor: '#F5F5F5' }} />
                        <Text style={{ flex: 1, fontStyle: 'normal', fontFamily: 'Proxima Nova',  marginBottom: 10, marginTop: 10, fontSize: responsiveFontSize(2), marginLeft: (responsiveScreenWidth(3.0) + 4), color: '#91AABE' }}> {this.props.rowData.name} </Text>
                    </View>
                </View>

            </ElevatedView>
            // </View>
        );
    }
});

export default NewsRow;
