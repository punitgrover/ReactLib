import React, { Component } from 'react';
import { View, Text, ScrollView, BackHandler, Dimensions } from 'react-native';
import ImageLoad from 'react-native-image-placeholder';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import * as Common from '../../common';
import { Actions } from 'react-native-router-flux';

const timer = require('../../Images/time.png');
var moment = require('moment');
var striptags = require('striptags');
import HTML from 'react-native-render-html';

class NewsDetails extends Component {
    componentWillMount(){       

        BackHandler.addEventListener('hardwareBackPress', () => {
                 Actions.pop();
            return true;
        });
    }
    componentDidUpdate(){
        BackHandler.removeEventListener('hardwareBackPress');
    }

    renderHTMLView() {
        const html = `${this.props.data.intro}${striptags(this.props.data.body)}`;
        return(
            <HTML baseFontStyle={{ color: '#565B60', fontStyle: 'normal', fontFamily: 'Proxima Nova', fontSize: responsiveFontSize(2), fontWeight: '300'}} containerStyle={{ marginLeft: 15, marginRight: 15, marginTop: 10 }} html={html} imagesMaxWidth={Dimensions.get('window').width} />
        );
    }
    
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'white' }}>
                {Common.addNavTitleWithback('News')}
                <View style={{ flex: 1, backgroundColor: 'transparent' }} >
                    <ScrollView contentContainerStyle={{ paddingTop: 0, paddingBottom: 20 }}>
                        <View style={{ flex: 1, height: responsiveScreenWidth(60), backgroundColor: 'transparent' }}>
                            <ImageLoad
                                loadingStyle={{ size: 'small', color: '#13AAEB' }}
                                source={{ uri: `${this.props.data.website}${this.props.data.thumbnail}`.replace('  ', '%20') }}
                                style={{ flex: 1, alignSelf: 'stretch' }} />
                            <Text style={{ flex: 1, fontStyle: 'normal', fontFamily: 'Proxima Nova', position: 'absolute', bottom: 20, color: 'white', fontSize: responsiveFontSize(3), fontWeight: '700', left: 20, right: 20 }}>{this.props.data.title}</Text>
                        </View>
                        <View style={{ flexDirection: 'row', margin: 15, backgroundColor: 'transparent' }}>
                            <Text style={{ flex: 2, fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#B3C3D0', fontSize: responsiveFontSize(1.7), fontWeight: '600' }}>{this.props.data.name}</Text>
                            <View style={{ flex: 1, marginLeft: 5, marginRight: 5, backgroundColor: 'transparent', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }} >
                                <Text style={{ color: '#B3C3D0', fontStyle: 'normal', fontFamily: 'Proxima Nova', fontSize: responsiveFontSize(1.7), fontWeight: '600' }} >{moment.unix(this.props.data.date).format("DD MMM YYYY").toUpperCase()}</Text>
                            </View>

                        </View>
                        <View style={{ width: null, height: 1, marginBottom: 0, backgroundColor: 'gray' }} />
                       {this.renderHTMLView()}
                        {/* <Text style={{ color: '#565B60', fontStyle: 'normal', fontFamily: 'Proxima Nova', fontSize: responsiveFontSize(2), fontWeight: '300', marginLeft: 15, marginRight: 15 }} >{striptags(this.props.data.body).replace('&rsquo;', '')}</Text> */}
                    </ScrollView>

                </View>
            </View>
        );
    }

}

export default NewsDetails;
