import React, { Component, } from 'react';
import { View, StyleSheet, TouchableHighlight, Text, Image, Dimensions } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { IndicatorViewPager, PagerTitleIndicator } from 'rn-viewpager';
import { EventRegister } from 'react-native-event-listeners';
import SplashScreen from 'react-native-splash-screen'
import * as Common from '../../common';
import NewsList from './newslist';
import * as Database from '../../database';

const chatImage = require('../../Images/chat-box.png');
const { hei, wid } = Dimensions.get('window');
class News extends Component {

  constructor(props) {
    super(props);
    this.state = {
      arrSchool: [],
      showPopup: true,
    };
  }

  componentWillMount() {

    this.getData();

    this.listener = EventRegister.addEventListener('updateFilter', (arrdata) => {
      this.setState({ arrSchool: arrdata });
      this.forceUpdate();        
    });
  }
  componentDidMount() {
    SplashScreen.hide();
  }

  getData() {
    Database.fetchListFromDB('School', (flag, data) => {
      if (flag) {
        this.setState({ arrSchool: data });
      }
    });
    Database.fetchListFromDB('ShowNavigator', (flag, data) => {
      if (flag) {
        if (data.length > 0) {
          this.setState({ showPopup: false });
        }
      }
    });
  }

  onSideMenuPress() {

  }
  _renderTitleIndicator() {
    var title = ['All'];
    this.state.arrSchool.map((data) => {
           title.push(data.name);
    });

    return <PagerTitleIndicator titles={title}
      itemTextStyle={{ color: '#84A0AE', fontSize: responsiveFontSize(2.3), fontStyle: 'normal', fontFamily: 'Proxima Nova' }}
      selectedItemTextStyle={{ color: '#2D2D2D', fontSize: responsiveFontSize(2.3), fontStyle: 'normal', fontFamily: 'Proxima Nova' }}
      selectedBorderStyle={{ backgroundColor: '#2D2D2D', height: 2 }}
      trackScroll={true}
    />;
  }

  updateNavigationRouter() {
    Database.saveTODB('ShowNavigator', { isShow: false }, (flag) => {
      if (flag) {
          this.setState({ showPopup: false });
      }
    });
  }

  showNavigationRouter() {

    if (this.state.showPopup) {
      return (
        <View style={{ flex: 1, position: 'absolute', bottom: 0, alignSelf: 'center', width: (Dimensions.get('window').width > 414 ? responsiveScreenWidth(70) : responsiveScreenWidth(80)), height: (Dimensions.get('window').width > 414 ? responsiveScreenWidth(40) : responsiveScreenWidth(50)), backgroundColor: 'transparent' }}>
          <Image source={chatImage} style={{ marginTop: 15, backgroundColor: 'transparent', width: (Dimensions.get('window').width > 414 ? responsiveScreenWidth(68) : responsiveScreenWidth(78)), alignSelf: 'center', height: (Dimensions.get('window').width > 414 ? responsiveScreenWidth(38) : responsiveScreenWidth(48)) }} resizeMode='stretch' />
          <View style={styles.popoverContainer}>
            <Text style={[styles.popoverText, { marginTop: (Dimensions.get('window').width > 414 ? responsiveScreenWidth(6) : responsiveScreenWidth(6)), }]}>
              Use this bar to keep up to
               </Text>
            <Text style={styles.popoverText}>
              date with your schools
               </Text>
            <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => this.updateNavigationRouter()}>
              <View style={{ height: (Dimensions.get('window').width > 414 ? responsiveScreenWidth(8) : responsiveScreenWidth(10)), width: (Dimensions.get('window').width > 414 ? responsiveScreenWidth(50) : responsiveScreenWidth(60)), marginBottom: 10, marginTop: (Dimensions.get('window').width > 414 ? 30 : 20), backgroundColor: '#13AAEB', justifyContent: 'center', alignItems: 'center', borderRadius: responsiveScreenWidth(5), }}>
                <Text style={styles.popoverText}>OK, GOT IT!</Text>
              </View>
            </TouchableHighlight>
          </View>
        </View>
      );
    }

  }
  renderNewsListView() {
    return this.state.arrSchool.map((rowData) => {
     return (
        <View style={{ flex: 1, backgroundColor: 'red' }}>
          <NewsList isAll={false} data={rowData} />
        </View>
      );
    });
  }
  render() {
    return (
      <View style={{ flex: 1, backgroundColor: 'white' }}>
        {Common.addNavTitle('News')}
        <View style={{ flex: 1, backgroundColor: 'transparent' }}>
          <IndicatorViewPager
            style={{ flex: 1, backgroundColor: 'white' }}
            indicator={this._renderTitleIndicator()}
          >
            <View style={{ flex: 1, backgroundColor: 'transparent' }}>
              <NewsList isAll data={this.state.arrSchool} />
            </View>
            {this.renderNewsListView()} 

          </IndicatorViewPager>


        </View>
        {this.showNavigationRouter()}
      </View>
    );
  }

}
const styles = StyleSheet.create({

  popoverContainer: {
    flex: 1,
    backgroundColor: 'transparent',
    padding: 8,
    borderRadius: 5,
    marginTop: 10,
    alignSelf: 'center',
    position: 'absolute',
    //  justifyContent: 'center',

    alignItems: 'center',
    width: (Dimensions.get('window').width > 414 ? responsiveScreenWidth(68) : responsiveScreenWidth(78)),
    height: (Dimensions.get('window').width > 414 ? responsiveScreenWidth(38) : responsiveScreenWidth(48))

  },
  popoverText: {
    color: 'white',
    fontFamily: 'Proxima Nova',
    fontStyle: 'normal',
    marginLeft: 15,
    marginRight: 15,
    // margin: 10,
    backgroundColor: 'transparent',
    textAlign: 'center',
    fontSize: responsiveFontSize(2.5)
  }
});

export default News;
