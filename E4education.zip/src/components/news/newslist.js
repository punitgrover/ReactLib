import React, { Component } from 'react';
import { View, TouchableHighlight, FlatList } from 'react-native';
import { responsiveWidth, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { RNProgressHUD } from 'react-native-simplest-hud';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import { NoSalonView } from '../common';
import logo from '../../Images/iTunesArtwork.png';
import { fetchSchoolNewsList } from '../../services/school';
import SharedManager from '../../common/sharedmanager';
import NewsRow from './newsrow';

class NewsList extends Component {

  constructor(props) {
    super(props);
    this.arrNews = [];
    this.state = {
      isLoading: true,
      refreshing: false,
      data: [],
    };
    this.onBackButtonAction = this.onBackButtonAction.bind(this);
    this.onSideMenuPress = this.onSideMenuPress.bind(this);
  }
  componentWillMount() {
    this.getData();
  }
  componentWillReceiveProps() {    
    this.setState({ isLoading: true });
    this.getData();
  }

  getData() {
    this.setState({
      isLoading: true
    })
    if (this.props.isAll === true) {
      const arrSchool = [];
      var arrData = [];
     try {
        arrData = Array.prototype.slice.apply(this.props.data);
        arrData.map((item) => {
          arrSchool.push({ siteid: item.siteid, categories: item.newscategories, lastupdated: 0 });
        });
      }catch(erorr){
     }
      this.callNewsApi({ device: SharedManager.getInstance().getDeviceID(), schools: arrSchool });
    } else {
     try {
      this.callNewsApi({ device: SharedManager.getInstance().getDeviceID(), schools: [{ siteid: this.props.data.siteid, categories: this.props.data.newscategories, lastupdated: 0 }] });
      }
      catch(error){
      }
    }
  }

  callNewsApi(postValue) {
    this.setState({ isLoading: true });    
    fetchSchoolNewsList(postValue, (flag, response, msg) => {
     if (flag) {
        SharedManager.getInstance().setDeviceID(response.api_deviceid);
        this.arrNews = [];
        response.schools.map((news) => {
          this.arrNews = this.arrNews.concat(news.news);
        });
        this.arrNews = this.arrNews.filter((item) => {
          return item.action !== 'remove';
        });
       const arr = this.bubbleSortDates(this.arrNews);
        this.arrNews = [];
        this.arrNews = arr;
      } else {
        Common.showAlertWithDefaultTitle(msg);
      }
      this.updateSchoolList();  
    });
  }
  bubbleSortDates = (arr) => {
    for(var i = arr.length - 1; i >= 0; i--) {
      for(var j = 1; j <= i; j++) {
        if (new Date(arr[j - 1].date) < new Date(arr[j].date)) {
          var temp = arr[j - 1];
          arr[j - 1] = arr[j];
          arr[j] = temp;
        }
      }
    }
    return arr;
  };

  updateSchoolList() {
    this.setState({
      isLoading: false,
      refreshing: false, 
      data: this.arrNews
    });
    this.forceUpdate();
  }

  onSideMenuPress() {
    Actions.main();
  }
  onBackButtonAction() {
    Actions.pop();
  }
  onPressRow(rowData) {
        Actions.newsdetails({ data: rowData });
  }

  onEndReached() {

  }
  onRefresh() {
    this.setState({
      refreshing: true,
      isLoading: true,
    });
    this.getData();
  }

  renderRow(rowData) {
    return (
      <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => this.onPressRow(rowData)}>
        <View style={[styles.style_row_view]}>
          <NewsRow {...rowData} rowData={rowData} />
        </View>
      </TouchableHighlight>
    );
  }
  checkData() {
    if (this.arrNews.length === 0 && !this.state.isLoading) {
      return (
        <NoSalonView
          imageName={logo}
          message='No Record Found'
          onPressRefresh={() => this.getData()}
        />
      );
    } else {
      return (
        <View style={{ flex: 1 }}>          
              <FlatList
                style={{ flex: 1 }}
                 onRefresh={() => this.onRefresh()}
                 refreshing={this.state.refreshing}
                 removeClippedSubviews={false}
                 data={this.state.data}
                 renderItem={({ item }) => (
                 this.renderRow(item)
                  )}
              />
        </View>
      );
    }
  }

  render() {
    return (
      <View style={{ flex: 1, backgroundColor: '#F1F5F8', width: responsiveScreenWidth(100) }}>
        {this.checkData()}
        <RNProgressHUD
          isVisible={this.state.isLoading}
          color='#434c54'
          label='Loading'
          isActivityIndicator
        />

      </View>
    );
  }

}

const styles = {

  style_row_view: {
    flex: 1,
  },
  filerStyle: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    width: responsiveWidth(14),
    height: responsiveWidth(14),
    backgroundColor: 'transparent',
    alignItems: 'center',
    justifyContent: 'center',

  }
};
export default NewsList;
