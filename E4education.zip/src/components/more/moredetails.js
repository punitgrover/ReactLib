import React, { Component } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { responsiveFontSize } from 'react-native-responsive-dimensions';
import * as Common from '../../common';
var striptags = require('striptags');
class MoreDetails extends Component {
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: '#F1F5F8' }}>
                {Common.addNavTitleWithback('Detail')}
                <View style={{ flex: 1, backgroundColor: 'transparent' }} >
                    <ScrollView contentContainerStyle={{ paddingTop: 0, paddingBottom: 20 }}>
                        <Text style={{ marginTop: 15, fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#565B60', fontSize: responsiveFontSize(2), fontWeight: '300', marginLeft: 10, marginRight: 10 }} >{striptags(this.props.data.body)}</Text>
                    </ScrollView>

                </View>
            </View>
        );
    }

}

export default MoreDetails;
