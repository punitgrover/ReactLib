import React, { Component } from 'react';
import { View, ListView, TouchableHighlight, RefreshControl } from 'react-native';
import { responsiveWidth } from 'react-native-responsive-dimensions';
import { RNProgressHUD } from 'react-native-simplest-hud';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import { NoSalonView } from '../common';
import logo from '../../Images/iTunesArtwork.png';
import * as Database from '../../database';
import SharedManager from '../../common/sharedmanager';
import { fetchSchoolPlaces } from '../../services/school';
import MoreRow from './morerow';

const school = require('../../Images/school.png');
const photo = require('../../Images/album.png');
const moreImage = require('../../Images/arrow_right.png');

class More extends Component {

  constructor(props) {
    super(props);
    const CompArray = [];
    this.pages = [];
    CompArray[0] = { image: school, title: 'Your Schools', body: 'View and edit your schools list' };
    CompArray[1] = { image: photo, title: 'Albums', body: 'View albums from all your schools' };
    this.arrMore = [];
    const ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => true });
    this.state = {
      dataSource: ds.cloneWithRows(this.arrMore),
      isLoading: true,
      refreshing: false,
      data: []
    };
  }
  componentWillMount() {
        this.getData();
}

getData(){
  const arrSchool = [];
  Database.fetchListFromDB('School', (flag, data) => {
    if (flag) {
      data.map((item) => {
        arrSchool.push({ siteid: item.siteid, lastupdated: 0 });
      });
    }
  });
  this.callPlaceApi({ device: SharedManager.getInstance().getDeviceID(), schools: arrSchool });
}

callPlaceApi(postValue) {
  
  fetchSchoolPlaces(postValue, (flag, response, msg) => {
        if (flag) {
          SharedManager.getInstance().setDeviceID(response.api_deviceid);
          
          const CompArray = [];
          this.pages = [];
          CompArray[0] = { image: school, title: 'Your Schools', body: 'View and edit your schools list' };
          CompArray[1] = { image: photo, title: 'Albums', body: 'View albums from all your schools' };
          this.arrMore = CompArray;
          response.schools.map((pages) => {
            this.pages = this.pages.concat(pages.pages);
          });
          for (const obj of this.pages) {
             obj.image = moreImage;
            if (obj.action !== undefined && obj.action !== 'remove') {
            this.arrMore.push(obj);
          }
          }

        } else {
          Common.showAlertWithDefaultTitle(msg);
        }
        this.updateSchoolList();
      });
    }
 
  updateSchoolList() {

    this.setState({
      dataSource: this.state.dataSource.cloneWithRows(this.arrMore),
      isLoading: false,
      refreshing: false,
    });
  }


  onEndReached() {
  }
  onPressRow(rowID, rowData) {
    switch (rowData.title) {
      case 'Your Schools':
               Actions.yourschool();
               break;
               
      case 'Albums':
            Actions.albums();
              break;     
      case 'Email us':
              email([this.props.data.email], null, null, 'My Subject', 'My body text');
          break;
      default:
        Actions.moredetails({ data : rowData });
      }
       this.updateSchoolList();       
     }

     _onRefresh() {
      this.setState({refreshing: true,
        isLoading: true,
      });
      this.getData();
      }
renderRow(rowData, sectionID, rowID) {
  return (
    <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => this.onPressRow(rowID, rowData)}>
      <View style={styles.style_row_view}>
        <MoreRow {...rowData} key={rowData.id} rowData={rowData} />
      </View>
    </TouchableHighlight>
  );
}
checkData() {
  if (this.arrMore.length === 0 && !this.state.isLoading) {
    return (
      <NoSalonView
        imageName={logo}
        message='No salon shops available'
      />
    );
  } else {
    return (
      <ListView
        style={{ backgroundColor: '#F1F5F8' }}
        dataSource={this.state.dataSource}
        renderRow={this.renderRow.bind(this)}
        enableEmptySections
        onEndReached={this.onEndReached.bind(this)}
        onEndReachedThreshold={0}
        refreshControl={
          <RefreshControl
            refreshing={this.state.refreshing}
            onRefresh={this._onRefresh.bind(this)}
          />
        }
      />
    );
  }
}

render() {
  return (
    <View style={{ backgroundColor: '#F1F5F8', flex: 1 }}>
      {Common.addNavTitle('More')}
      {this.checkData()}

      <RNProgressHUD
        isVisible={this.state.isLoading}
        color='#434c54'
        label='Loading'
        isActivityIndicator
      />
    </View>
  );
}

}

const styles = {

  style_row_view: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#F1F5F8',
  },
  filerStyle: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    width: responsiveWidth(14),
    height: responsiveWidth(14),
    backgroundColor: 'transparent',
    alignItems: 'center',
    justifyContent: 'center',

  }
};

export default More;
