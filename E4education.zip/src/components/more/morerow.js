import React from 'react';
import { View, Text, Image } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
var striptags = require('striptags');
var createReactClass = require('create-react-class');
import * as Database from '../../database';
var MoreRow = createReactClass({

  drowLine() {
    if (this.props.rowData.siteid !== undefined) {
        Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.siteid + '"', (flag, data) => {
            if (flag) {
                if (data.length > 0) {
                    this.props.rowData.colour = data[0].colour;
                    this.props.rowData.name = data[0].name;
                    this.props.rowData.website = data[0].website;
                } else {
                    this.props.rowData.colour = '#97ADBA';
                }
            } else {
                this.props.rowData.colour = '#97ADBA';
            }
        });
    } else {
        this.props.rowData.colour = '#97ADBA';
    }
    return (
        <View style={{ height: null, width: 4, backgroundColor: this.props.rowData.colour }} >
          <Text />
        </View>
    );
},

rederImage(){
  var width = 8;
  if (this.props.rowData.title !== 'Your Schools' && this.props.rowData.title !== 'Albums' ){
    width = 4;
  }  
  return (
    <Image source={this.props.rowData.image} style={{ alignSelf: 'center', width: responsiveScreenWidth(width), height: responsiveScreenWidth(width), resizeMode: 'cover', backgroundColor: 'transparent' }} />
  );

},
  render: function () {
    return (
      <View style={{ flex: 1, marginLeft: 5, marginRight: 5, marginBottom: 5, flexDirection: 'row', backgroundColor: 'transparent' }} >
        {/* <View style={{hieght: null, width: 4, backgroundColor: 'red'}} />
       */}
       {this.drowLine()}  
       
        <View style={{ flex: 500, backgroundColor: 'transparent', flexDirection: 'row' }}>
          <View style={{ width: responsiveScreenWidth(15), height: responsiveScreenWidth(15), backgroundColor: 'transparent', justifyContent: 'center', alignItems: 'center', }}>
      {this.rederImage()}
            
          </View>
          <View style={{ flex: 1, width: responsiveScreenWidth(85), backgroundColor: 'transparent', justifyContent: 'center'}} >
            <Text style={{ flex: 1, fontStyle: 'normal', fontFamily: 'Proxima Nova', fontSize: responsiveFontSize(2.2), color: '#52585B', fontWeight: '500', marginTop: 5, backgroundColor: 'transparent' }}>{this.props.rowData.title} </Text>
            <Text style={{ flex: 1, fontStyle: 'normal', fontFamily: 'Proxima Nova', fontSize: responsiveFontSize(2), color: '#ACBECA', fontWeight: '200', marginTop: 2, marginBottom: 5, }} numberOfLines={1}>{striptags(this.props.rowData.body)}</Text>
          </View>
          </View>
        
        <View style={{ flex: 1, height: 0.5, backgroundColor: '#E6EBEF' }} />
      </View>
    );
  }
});

export default MoreRow;