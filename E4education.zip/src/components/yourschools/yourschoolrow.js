import React from 'react';
import { View, Text, Image, TouchableHighlight } from 'react-native';

import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import ElevatedView from 'react-native-elevated-view';
var createReactClass = require('create-react-class');


var YourSchoolRow = createReactClass({
    renderImage() {
        const str = this.props.rowData.thumbnail;
        const url = str.replace('  ', '%20');
        return (
            <Image source={{ uri: url }} style={{ flex: 1, backgroundColor: 'transparent', margin: 20 }} resizeMode='contain' />
        );
    },
    renderBlankView() {
        return (
            <View style={{ flex: 1, backgroundColor: 'transparent' }} />
        );
    },

renderAddressText() {
    var address = '';
   if (this.props.rowData.street.length > 0 ){
        address = address +  this.props.rowData.street + ',';
    }
    if (this.props.rowData.town.length > 0 ){
        address = address +  this.props.rowData.town + ',';
    }
    address = address + this.props.rowData.locality

    return(
        <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#8F9BA8', fontSize: responsiveFontSize(2), marginLeft: responsiveScreenWidth(3.0), marginTop: responsiveScreenWidth(4.5) }} >{address}</Text>
    );
},

    render: function () {
               // debugger
        return (
            <ElevatedView 
            elevation={3}
            style={{ flex: 1, backgroundColor: 'white', marginTop: 10, marginLeft: 10, marginRight: 10,
           
            shadowOffset: { width: 1.5, height: 1.5 },
            shadowColor: 'gray',
            shadowOpacity: 1.0,
            marginBottom: 10,
             }}>
                <View style={{ flex: 1}}>
                    <View style={{ flex: 1, width: null, backgroundColor: 'transparent', flexDirection: 'row' }}>
                        <View style={{ width: responsiveScreenWidth(35.0), height: responsiveScreenWidth(35.0), backgroundColor: this.props.rowData.colour }} >
                            {this.props.rowData.thumbnail !== null ? this.renderImage() : this.renderBlankView()}
                        </View>
                        <View style={{ flex: 1, height: responsiveScreenWidth(35.0), width: null, backgroundColor: 'white', justifyContent: 'center', alignContent: 'center' }} >
                            <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#444A4E', fontSize: responsiveFontSize(2.2), fontWeight: '600', marginLeft: responsiveScreenWidth(3.0), marginTop: 15 }} >{this.props.rowData.name}</Text>
                            {this.renderAddressText()}
                            <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#8F9BA8', fontSize: responsiveFontSize(2), marginLeft: responsiveScreenWidth(3.0), marginBottom: 15 }} >{this.props.rowData.postcode}</Text>
                        </View>
                    </View>

                </View>
                <View style={{ flex: 1, height: responsiveScreenWidth(12), backgroundColor: 'white', marginLeft: responsiveScreenWidth(3.0), marginRight: responsiveScreenWidth(3.0) }}>
                    <View style={{ width: null, height: 0.5, backgroundColor: '#d3d3d3' }} />
                    <View style={{ flex: 1, backgroundColor: 'transparent', flexDirection: 'row' }} >
                        <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ flex: 1 }} onPress={this.props.onPressContact}>
                            <View style={{ flex: 1, backgroundColor: 'transparent', flexDirection: 'row', justifyContent: 'center', alignContent: 'center' }}>
                                <Image source={require('../../Images/contact.png')} style={{ alignSelf: 'center', backgroundColor: 'transparent', width: responsiveScreenWidth(3), height: responsiveScreenWidth(3), resizeMode: 'contain' }} />
                                <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', alignSelf: 'center', backgroundColor: 'transparent', color: '#AEC5CB', fontSize: responsiveFontSize(1.9) }} > CONTACT </Text>
                            </View>
                        </TouchableHighlight>
                        <View style={{ width: 0.5, height: null, backgroundColor: '#d3d3d3' }} />
                        <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ flex: 1, backgroundColor: 'transparent' }} onPress={this.props.onPressSetting}>
                            <View style={{ flex: 1, backgroundColor: 'transparent', flexDirection: 'row', justifyContent: 'center', alignContent: 'center' }} >
                                <Image source={require('../../Images/setting.png')} style={{ alignSelf: 'center', backgroundColor: 'transparent', width: responsiveScreenWidth(3), height: responsiveScreenWidth(3), resizeMode: 'contain' }} />
                                <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', alignSelf: 'center', backgroundColor: 'transparent', color: '#AEC5CB', fontSize: responsiveFontSize(1.9) }} > SETTINGS </Text>
                            </View>
                        </TouchableHighlight>
                        <View style={{ width: 0.5, height: null, backgroundColor: '#d3d3d3' }} />
                        <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ flex: 1 }} onPress={this.props.onPressRemove}>
                            <View style={{ flex: 1, backgroundColor: 'transparent', flexDirection: 'row', justifyContent: 'center', alignContent: 'center' }} >
                                <Image source={require('../../Images/delete.png')} style={{ alignSelf: 'center', backgroundColor: 'transparent', width: responsiveScreenWidth(3), height: responsiveScreenWidth(3), resizeMode: 'contain' }} />
                                <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', alignSelf: 'center', backgroundColor: 'transparent', color: '#AEC5CB', fontSize: responsiveFontSize(1.9) }} > REMOVE</Text>
                            </View>
                        </TouchableHighlight>
                    </View>
                </View>
            </ElevatedView>
        );
    }
});

export default YourSchoolRow;
