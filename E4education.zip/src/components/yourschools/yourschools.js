import React, { Component } from 'react';
import { View, BackHandler, FlatList } from 'react-native';
import { responsiveWidth } from 'react-native-responsive-dimensions';
import { Actions } from 'react-native-router-flux';
import { RNProgressHUD } from 'react-native-simplest-hud';
import * as Common from '../../common';
import YourSchoolRow from './yourschoolrow';
import * as Database from '../../database';
import { EventRegister } from 'react-native-event-listeners';

class YourSchool extends Component {

    constructor(props) {
        super(props);
        this.arrSchool = [];
        this.state = {
            isLoading: true,
            data: []
        };
        this.onBackPress = this.onBackPress.bind();
        this.onPlusPress = this.onPlusPress.bind();
    }
    componentWillMount() {
        BackHandler.addEventListener('hardwareBackPress', () => {
            Actions.pop();
       return true;
        });
        Database.fetchListFromDB('School', (flag, data) => {
            if (flag) {
                this.arrSchool = data;
                this.updateSchoolList();
            }
        });
    }
    componentDidUpdate(){
        BackHandler.removeEventListener('hardwareBackPress');
    }
    updateSchoolList() {        
            this.setState({
               isLoading: false,
                data: this.arrSchool,
            });
            if (this.arrSchool.length === 0)
            {
                EventRegister.emit('setScene', false);
            }
    }

    onPressContact(rowData) {
        Actions.contact({ data: rowData });
    }
    onPressSetting(rowData) {
        // debugger;
        Actions.setting({ data: rowData });
    }
    deleteSchoolFromDB(object) { 
        const siteId = object[0].siteid;        
        try { 
            Database.realm.write(() => {
                Database.realm.delete(object);                
                    EventRegister.emit('updateFilter', this.arrSchool);
                    this.updateSchoolList();   
           });                
        }catch(error){
        }
    }

    onPressRemove(rowData) {
        const actions = [
            { text: 'No', onPress: () => {} },
            {
                text: 'Yes',
                onPress: () => {
                    Database.fetchDataWithIdFromDB('School', 'id = "' + rowData.id + '"', (flag, object) => {
                        if (flag) {
                            this.setState({isLoading: true });
                            this.deleteSchoolFromDB(object);
                        }
                    });
                }
            }
        ];
        Common.showAlertWithCustomAction('Are you sure you wish to remove this school from the app?', actions);
    }

    renderRow(rowData, sectionID, rowID) {
        return (
            <View style={styles.style_row_view}>
                <YourSchoolRow {...rowData} key={rowData.id} rowData={rowData} onPressContact={() => this.onPressContact(rowData)} onPressSetting={() => this.onPressSetting(rowData)} onPressRemove={() => this.onPressRemove(rowData)} />
            </View>
        );
    }

    onBackPress(){
        Actions.pop();
    }
    onPlusPress() {  
        Actions.postcodevc();
    }
    render() {
               return (
            <View style={{ backgroundColor: 'green', flex: 1 }}>
                {Common.addSearchBar('Your schools', this.onPlusPress, this.onBackPress)}
                <FlatList
                    style={{ backgroundColor: '#F1F5F8' }}
                    ref={(list) => { this.flatListRef = list; }}
                    data={this.state.data}
                    extraData={this.state}
                    renderItem={({ item }) => (
                    this.renderRow(item)
                    )}
                />
                <RNProgressHUD
                    isVisible={this.state.isLoading}
                    color='#434c54'
                    label='Loading'
                    isActivityIndicator
                />
            </View> 
        );
    }

}

const styles = {

    style_row_view: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '#F1F5F8',
    },
    filerStyle: {
        position: 'absolute',
        bottom: 8,
        right: 8,
        width: responsiveWidth(14),
        height: responsiveWidth(14),
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',

    }
};

export default YourSchool;
