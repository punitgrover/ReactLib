import React, { Component } from 'react';
import { View, ListView, Text, TouchableHighlight, BackHandler, FlatList } from 'react-native';
import { responsiveWidth, responsiveScreenWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import { RNProgressHUD } from 'react-native-simplest-hud';
import { fetchSchoolCategories } from '../../services/school';
import * as Database from '../../database';
import SharedManager from '../../common/sharedmanager';
import { NoSalonView } from '../common';
import logo from '../../Images/iTunesArtwork.png';

import NewsCategoriesRow from './newscategoriesrow';

class NewsCategories extends Component {

    constructor(props) {
        super(props);
        this.arrCategories = [];
      //  const ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => true });
        this.state = {
          //  dataSource: ds.cloneWithRows(this.arrCategories),
            isLoading: true,
            data: []
        };
    }
   
    componentWillMount() {
        BackHandler.addEventListener('hardwareBackPress', () => {
            Actions.pop();
       return true;
        });
       this.callSchoolCategories({ device: SharedManager.getInstance().getDeviceID(), schools: [{ siteid: this.props.siteID, lastupdated: 0 }] });
     }
     componentDidUpdate(){
        BackHandler.removeEventListener('hardwareBackPress');
    }
     callSchoolCategories(postValue) {
         
         fetchSchoolCategories(postValue, (flag, response, msg) => {
               if (flag) {
                 SharedManager.getInstance().setDeviceID(response.api_deviceid);
                 response.schools.map((categories) => {
                    this.filterData(categories.categories);                      
                 });
                 }                 
                else {
                this.updateSchoolList();
                 Common.showAlertWithDefaultTitle(msg);
               }               
             });
           }

    filterData(categories) {  

        // rowData.newscategories = '';
        // rowData.eventscategories = '';
        // rowData.albumscategories = '';

      if (this.props.data.name === 'News Categories') {
        //   debugger
             if (Object.keys(categories).length > 0) {
              
                const news = [];
                for (var k in categories.news){
                    if (categories.news.hasOwnProperty(k)) {
                        news.push({ id: k, name: categories.news[k] });
                    }
                }
                this.arrCategories = news;
                if (this.arrCategories.length > 0)  {
                    Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.siteID + '"', (flag, object) => {
                        if (flag) {
                                 const arr = object[0].newscategories.split(',');
                                 this.arrCategories.map((item) => {
                                        arr.map((data) => {
                                            if (item.id === data){
                                                item.status = true;
                                            }
                                        });
                                 });

                         }
                    });
                }
                this.updateSchoolList();
              }else{
                this.updateSchoolList();
             }
      } else if (this.props.data.name === 'Events Categories') {
        if (Object.keys(categories).length > 0) {
            const events = [];
            for (var k in categories.events){
                if (categories.events.hasOwnProperty(k)) {
                    events.push({ id: k, name: categories.events[k] });
                }
            }
            this.arrCategories = events;
            if (this.arrCategories.length > 0)  {
                Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.siteID + '"', (flag, object) => {
                    if (flag) {
                             const arr = object[0].eventscategories.split(',');
                             this.arrCategories.map((item) => {
                                    arr.map((data) => {
                                        if (item.id === data){
                                            item.status = true;
                                        }
                                    });
                             });

                     }
                });
            }
            this.updateSchoolList();
          }else{
            this.updateSchoolList();
         }

      } else {
        if (Object.keys(categories).length > 0) {
           const albums = [];
            for (var k in categories.albums){
                if (categories.albums.hasOwnProperty(k)) {
                    albums.push({ id: k, name: categories.albums[k] });
                }
            }
            this.arrCategories = albums;
            console.log(this.props.siteID);
            console.log(this.arrCategories);
            if (this.arrCategories.length > 0)  {
                Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.siteID + '"', (flag, object) => {
                   if (flag) {
                             const arr = object[0].albumscategories.split(',');
                             this.arrCategories.map((item) => {
                                    arr.map((data) => {
                                        if (item.id === data){
                                            item.status = true;
                                        }
                                    });
                             });

                     }
                });
            }
             this.updateSchoolList();
          }else{
            this.updateSchoolList();
         }
      }     
    }       

    updateSchoolList() {
        this.setState({
            isLoading: false,
            data: this.arrCategories
        });
    }
    toggleSwitch(rowData) {
        // debugger
        if (this.props.data.name === 'News Categories') {
            Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.siteID + '"', (flag, object) => {
              if (flag) {
                        const realmObjext = object[0];
                        const arr = realmObjext.newscategories.split(',');
                      
                        if (arr.includes(rowData.id)){
                            arr.splice(arr.indexOf(rowData.id), 1);
                                Database.realm.write(() => {
                                realmObjext.newscategories = arr.join();
                            });
                            this.arrCategories.map((item) => {
                                if(rowData.id === item.id) {
                                    item.status = false;
                                }
                            })
                           
                            this.updateSchoolList();
                            
                        }else{
                            
                            arr.push(rowData.id);
                            Database.realm.write(() => {
                                realmObjext.newscategories = arr.join();
                            });
                            this.arrCategories.map((item) => {
                                if(rowData.id === item.id) {
                                    item.status = true;
                                }
                            })
                           
                            this.updateSchoolList();
                        }                      
                }
           });

        } else if (this.props.data.name === 'Events Categories') {
            Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.siteID + '"', (flag, object) => {
              
                if (flag) {
                        const realmObjext = object[0];
                        const arr = realmObjext.eventscategories.split(',');
                       
                        if (arr.includes(rowData.id)){
                            arr.splice(arr.indexOf(rowData.id), 1);
                                Database.realm.write(() => {
                                realmObjext.eventscategories = arr.join();
                            });
                            this.arrCategories.map((item) => {
                                if(rowData.id === item.id) {
                                    item.status = false;
                                }
                            })
                            
                            this.updateSchoolList();
                            
                        }else{
                           
                            arr.push(rowData.id);
                            Database.realm.write(() => {
                                realmObjext.eventscategories = arr.join();
                            });
                            this.arrCategories.map((item) => {
                                if(rowData.id === item.id) {
                                    item.status = true;
                                }
                            })
                            
                            this.updateSchoolList();
                        }                      
                }
           });

        } else {

            Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.siteID + '"', (flag, object) => {
               
                if (flag) {
                        const realmObjext = object[0];
                        const arr = realmObjext.albumscategories.split(',');
                       
                        if (arr.includes(rowData.id)){
                            arr.splice(arr.indexOf(rowData.id), 1);
                                Database.realm.write(() => {
                                realmObjext.albumscategories = arr.join();
                            });
                            this.arrCategories.map((item) => {
                                if(rowData.id === item.id) {
                                    item.status = false;
                                }
                            })
                            
                            this.updateSchoolList();
                            
                        }else{
                             
                            arr.push(rowData.id);
                            Database.realm.write(() => {
                                realmObjext.albumscategories = arr.join();
                            });
                            this.arrCategories.map((item) => {
                                if(rowData.id === item.id) {
                                    item.status = true;
                                }
                            })
                            
                            this.updateSchoolList();
                        }                      
                }
           });

        }
        // rowData.status = rowData.status === undefined ? true : !rowData.status;
        this.updateSchoolList();
    }
    onPressRow(rowData) {
        this.updateSchoolList();
    }

    renderRow(rowData) {
        return (
            // <TouchableHighlight onPress={() => this.onPressRow(rowID, rowData)}>
                <View style={styles.style_row_view}>
                    <NewsCategoriesRow {...rowData} owData={rowData} toggleSwitch={() => this.toggleSwitch(rowData)} />
                </View>
            // </TouchableHighlight>

        );
    }
    checkData() {
        if (this.arrCategories.length === 0 && !this.state.isLoading) {
          return (
            <NoSalonView
              imageName={logo}
              message='No Record Found'
            />
          );
        } else {
          return (


            <FlatList
            style={{ backgroundColor: '#F1F5F8' }}
             ref={(list) => { this.flatListRef = list; }}
// onRefresh={() => this.onRefresh()}
// refreshing={this.state.refreshing}
// removeClippedSubviews={false}
// legacyImplementation
// viewabilityThreshold={0}r
// initialListSize={1000}
// //    data={this.state.stories}
// keyExtractor={(item, index) => item.id}
data={this.state.data}
extraData={this.state}
renderItem={({ item }) => (
this.renderRow(item)
)}
/>
        //     <ListView
        //     style={{ backgroundColor: '#F1F5F8' }}
        //     dataSource={this.state.dataSource}
        //     renderRow={this.renderRow.bind(this)}
        //     enableEmptySections
        // />
          );
        }
      }
    

    render() {
        return (
            <View style={{ backgroundColor: '#F1F5F8', flex: 1 }}>
                {Common.addNavTitleWithback(this.props.data.name)}
                <View style={{ height: responsiveScreenWidth(10), backgroundColor: 'transparent', justifyContent: 'center', alignContent: 'center' }}>
                    <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', backgroundColor: '', textAlign: 'center', fontSize: responsiveFontSize(2), color: '#364A52' }}>Please select the categories you wish to include</Text>
                </View>
                <View style={{ backgroundColor: '#EBF0F4', height: 1 }} />
                {this.checkData()}
        <RNProgressHUD
          isVisible={this.state.isLoading}
          color='#434c54'
          label='Loading'
          isActivityIndicator
        />
            </View>
        );
    }

}

const styles = {

    style_row_view: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '#F1F5F8',
    },
    filerStyle: {
        position: 'absolute',
        bottom: 8,
        right: 8,
        width: responsiveWidth(14),
        height: responsiveWidth(14),
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',

    }
};

export default NewsCategories;
