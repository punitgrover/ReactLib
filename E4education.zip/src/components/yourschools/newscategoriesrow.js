import React from 'react';
import { View, Text, Switch } from 'react-native';
import { responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';


var createReactClass = require('create-react-class');

var NewsCategoriesRow = createReactClass({

  render: function () {
    return (
      <View style={{ flex: 1, backgroundColor: 'transparent', marginTop: responsiveWidth(5), marginBottom: responsiveWidth(5), marginLeft: 20, marginRight: 20, shadowColor: 'gray', shadowOffset: { width: 1.5, height: 1.5 }, shadowOpacity: 1.0,  }}>
        <View style={{ flex: 1, backgroundColor: 'transparent', alignContent: 'center', justifyContent: 'center', flexDirection: 'row' }} >
          <Text style={{ flex: 1, fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#334656', alignSelf: 'center', fontSize: responsiveFontSize(2.3), fontWeight: '300' }} > {this.props.name} </Text>
          <Switch style={{ alignSelf: 'flex-end' }} onValueChange={this.props.toggleSwitch} value={this.props.status} onTintColor='#13AAEB' tintColor='#F1F5F8' thumbTintColor='white' />
        </View>
      </View>
    );
  }
});

export default NewsCategoriesRow;
