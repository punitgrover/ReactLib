import React, { Component } from 'react';
import { View, ListView, Image, Text, TouchableHighlight, BackHandler } from 'react-native';
import { responsiveWidth, responsiveScreenWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import { Actions } from 'react-native-router-flux';
import openMap from 'react-native-open-maps';
import { phonecall, email } from 'react-native-communications';
import { RNProgressHUD } from 'react-native-simplest-hud';
import Geocoder from 'react-native-geocoder';
import * as Common from '../../common';
import ContactRow from './contactrow';

const map = require('../../Images/map.png');
const callImage = require('../../Images/call.png');
const emailImage = require('../../Images/email_us.png');

class Contact extends Component {

    constructor(props) {
        super(props);
        var CompArray = [];
        this.address = '';
        if (this.props.data.street.length > 0 ){
            this.address = this.address +  this.props.data.street + ',';
         }
         if (this.props.data.town.length > 0 ){
            this.address = this.address +  this.props.data.town + ',';
         }
         if (this.props.data.locality.length > 0) {
         this.address = this.address + this.props.data.locality + ',';
        }
        if (this.props.data.postcode.length > 0) {
            this.address = this.address + this.props.data.postcode;
        }

        CompArray[0] = { image: map, name: 'Find our school', desc:  this.address };
        CompArray[1] = { image: callImage, name: 'Give us a call', desc: this.props.data.telephone };
        CompArray[3] = { image: emailImage, name: 'Email us', desc: this.props.data.email };

        this.arrInfo = CompArray;
        const ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => true });
        this.state = {
            dataSource: ds.cloneWithRows(this.arrInfo),
            isLoading: true,
            data: [],
            lat: 0,
            long: 0,
        };
    }
    componentWillMount() {
      
        BackHandler.addEventListener('hardwareBackPress', () => {
            Actions.pop();
       return true;
        });
        // Address Geocoding
    Geocoder.geocodeAddress(this.address).then(res => {
        
        if (res.length > 0) {
            this.setState({
                lat: res[0].position.lat,
                long: res[0].position.lng
            });
        }
        this.updateSchoolList();
    // res is an Array of geocoding object (see below)
})
.catch(err => {})
// debugger
        this.updateSchoolList();
    }
    componentDidUpdate(){
        BackHandler.removeEventListener('hardwareBackPress');
    }

    updateSchoolList() {
        this.setState({
            dataSource: this.state.dataSource.cloneWithRows(this.arrInfo),
            isLoading: false
        });
    }

    onPressRow(rowID, rowData) {
        // openMap({ latitude: 26.8619088, longitude: 75.8170636 });

        switch (rowData.name) {
            case 'Find our school':
                if (this.state.lat !== 0 && this.state.long !== 0)  {
                    openMap({ latitude: this.state.lat, longitude: this.state.long });
                }else{
                    Common.showAlertWithDefaultTitle('Sorry, Location not found.');
                }
                break;

            case 'Give us a call':
                phonecall(this.props.data.telephone, true);
                break;
            case 'Email us':
                email([this.props.data.email], null, null, 'My Subject', 'My body text');
                break;
            default:

        }


        this.updateSchoolList();
    }



    renderRow(rowData, sectionID, rowID) {
        return (
            <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => this.onPressRow(rowID, rowData)}>
                <View style={styles.style_row_view}>
                    <ContactRow {...rowData} key={rowData.id} rowData={rowData} />
                </View>
            </TouchableHighlight>

        );
    }

    render() {
        return (
            <View style={{ backgroundColor: '#F1F5F8', flex: 1 }}>
                {Common.addNavTitleWithback('Contact')}
                <View style={{ width: null, backgroundColor: this.props.data.colour, height: responsiveScreenWidth(30), justifyContent: 'center', alignContent: 'center' }}>
                    <Image source={{ uri: this.props.data.thumbnail }} style={{ alignSelf: 'center', width: responsiveScreenWidth(20), height: responsiveScreenWidth(20), backgroundColor: 'transparent', resizeMode: 'contain' }} />
                </View>
                <View style={{ height: responsiveScreenWidth(10), backgroundColor: 'transparent', justifyContent: 'center', alignContent: 'center' }}>
                    <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', backgroundColor: '', textAlign: 'center', fontSize: responsiveFontSize(2.2), color: '#565B60' }}>{this.props.data.name}</Text>
                </View>
                <View style={{ backgroundColor: '#EBF0F4', height: 1 }} />
                <ListView
                    style={{ backgroundColor: '#F1F5F8' }}
                    dataSource={this.state.dataSource}
                    renderRow={this.renderRow.bind(this)}
                    enableEmptySections
                />
                {/* {this.checkData()} */}
                 <RNProgressHUD
                         isVisible={this.state.isLoading}
                          color='#434c54'
                             label='Loading'
                             isActivityIndicator
                    />
            </View>
        );
    }

}

const styles = {

    style_row_view: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '#F1F5F8',
    },
    filerStyle: {
        position: 'absolute',
        bottom: 8,
        right: 8,
        width: responsiveWidth(14),
        height: responsiveWidth(14),
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',

    }
};

export default Contact;
