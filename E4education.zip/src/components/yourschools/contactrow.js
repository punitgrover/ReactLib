import React from 'react';
import { View, Text, Image, } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import ElevatedView from 'react-native-elevated-view';

var createReactClass = require('create-react-class');

var ContactRow = createReactClass({

 render: function() {
        //  debugger;
      return (
        <ElevatedView 
        elevation={3}
        style={{ flex: 1, backgroundColor: 'white', marginTop: 20, marginLeft: 20, marginRight: 20,
        shadowColor: 'gray', 
        shadowOffset: { width: 1.5, height: 1.5 },
        shadowOpacity: 1.0,
        marginBottom: 10,
        shadowOpacity: 0.8 }}>
          <View style={{flex: 1, backgroundColor: 'white', alignContent: 'center', justifyContent: 'center' }} >
          <Image source={this.props.image} style={{ marginTop: 10, alignSelf: 'center', width: responsiveScreenWidth(8), height: responsiveScreenWidth(8), resizeMode: 'contain', backgroundColor: 'transparent'}} />   
           <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', marginTop: 5, flex: 1, backgroundColor: 'transparent', alignSelf: 'center', fontSize: responsiveFontSize(2.8), fontWeight: '500' }} > {this.props.name} </Text>     
           <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', marginTop: 5, marginBottom: 15, flex: 1, backgroundColor: 'transparent', alignSelf: 'center', fontSize: responsiveFontSize(2), fontWeight: '200'}}> {this.props.desc} </Text>  
           </View>
        </ElevatedView>
      );
    }
    });

export default ContactRow;
