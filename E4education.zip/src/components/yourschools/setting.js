import React, { Component } from 'react';
import { View, ListView, Image, Text, TouchableHighlight, BackHandler } from 'react-native';
import { responsiveWidth, responsiveScreenWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import SettingRow from './settingrow';


class Settings extends Component {

    constructor(props) {
        super(props);
        var CompArray = [];
        CompArray[0] = { name: 'News Categories' };
        CompArray[1] = { name: 'Events Categories' };
        CompArray[3] = { name: 'Album Categories' };

        this.arrCategories = CompArray;
        const ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => true });
        this.state = {
            dataSource: ds.cloneWithRows(this.arrCategories),
            isLoading: true,
            data: []
        };
    }
    componentWillMount() {
        BackHandler.addEventListener('hardwareBackPress', () => {
            Actions.pop();
       return true;
        });
        // this.updateSchoolList();
    }
    componentDidUpdate(){
        BackHandler.removeEventListener('hardwareBackPress');
    }
    updateSchoolList() {
        this.setState({
            dataSource: this.state.dataSource.cloneWithRows(this.arrCategories),
            isLoading: false
        });
    }

    onPressRow(rowID, rowData) {
        Actions.newscategories({ data: rowData, siteID: this.props.data.siteid });
        this.updateSchoolList();
    }
    renderImage() {
        const str = this.props.data.thumbnail;
        const url = str.replace('  ', '%20');
        return (
            <Image source={{ uri: url }} style={{ flex: 1, backgroundColor: 'transparent', margin: 20 }} resizeMode='contain' />
        );
    } renderBlankView() {
        return (
            <View style={{ flex: 1, backgroundColor: 'transparent' }} />
        );
    }
    renderRow(rowData, sectionID, rowID) {
        return (
            <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => this.onPressRow(rowID, rowData)}>
                <View style={styles.style_row_view}>
                    <SettingRow {...rowData} key={rowData.id} rowData={rowData} />
                </View>
            </TouchableHighlight>
        );
    }

    render() {
        return (
            <View style={{ backgroundColor: '#F1F5F8', flex: 1 }}>
                {Common.addNavTitleWithback('Settings')}
                <View style={{ width: null, backgroundColor: this.props.data.colour, height: responsiveScreenWidth(30), justifyContent: 'center', alignContent: 'center' }}>
                {this.props.data.thumbnail !== null ? this.renderImage() : this.renderBlankView()}{/* <Image source={{ uri: this.props.data.thumbnail }} style={{ alignSelf: 'center', width: responsiveScreenWidth(20), height: responsiveScreenWidth(20), backgroundColor: 'transparent', resizeMode: 'contain' }} /> */}
                </View>
                <View style={{ height: responsiveScreenWidth(10), backgroundColor: 'transparent', justifyContent: 'center', alignContent: 'center' }}>
                    <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', backgroundColor: '', textAlign: 'center', fontSize: responsiveFontSize(2.2), color: '#565B60' }}>{this.props.data.name}</Text>
                </View>
                <View style={{ backgroundColor: '#EBF0F4', height: 1 }} />
                <ListView
                    style={{ backgroundColor: '#F1F5F8' }}
                    dataSource={this.state.dataSource}
                    renderRow={this.renderRow.bind(this)}
                    enableEmptySections
                />
            </View>
        );
    }

}

const styles = {

    style_row_view: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '#F1F5F8',
    },
    filerStyle: {
        position: 'absolute',
        bottom: 8,
        right: 8,
        width: responsiveWidth(14),
        height: responsiveWidth(14),
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',

    }
};

export default Settings;
