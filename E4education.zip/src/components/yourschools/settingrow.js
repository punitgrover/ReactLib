import React from 'react';
import { View, Text, Image } from 'react-native';
import { responsiveWidth, responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import ElevatedView from 'react-native-elevated-view';
var createReactClass = require('create-react-class');
const rightArrow = require('../../Images/arrow_right.png');
var SettingRow = createReactClass({

  render: function () {
    return (
      <ElevatedView 
      elevation={3}
      style={{ flex: 1, backgroundColor: 'transparent', marginTop: responsiveWidth(5), marginBottom: responsiveWidth(5), marginLeft: 20, marginRight: 20, shadowColor: 'gray', shadowOffset: { width: 1.5, height: 1.5 }, shadowOpacity: 1.0, }}>
        <View style={{ flex: 1, backgroundColor: 'transparent', alignContent: 'center', justifyContent: 'center', flexDirection: 'row' }} >
          <Text style={{ flex: 1, fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#334656', alignSelf: 'center', fontSize: responsiveFontSize(2.3), fontWeight: '300' }} > {this.props.name} </Text>
          <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#334656', alignSelf: 'center', fontSize: responsiveFontSize(1.8), fontWeight: '100', marginRight: 10, marginLeft: 10 }}>SELECT</Text>
          <Image source={rightArrow} style={{ alignSelf: 'center', width: responsiveScreenWidth(3), height: responsiveScreenWidth(3), resizeMode: 'contain', backgroundColor: 'transparent' }} />
        </View>
      </ElevatedView>
    );
  }
});

export default SettingRow;
