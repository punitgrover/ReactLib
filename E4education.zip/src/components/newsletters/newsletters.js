import React, { Component } from 'react';
import { View } from 'react-native';
import { responsiveFontSize } from 'react-native-responsive-dimensions';
import { IndicatorViewPager, PagerTitleIndicator } from 'rn-viewpager';
import { EventRegister } from 'react-native-event-listeners';
import * as Common from '../../common';
import * as Database from '../../database';
import NewsLettersList from './newsletterslist';

class NewsLetters extends Component {

    constructor(props) {
        super(props);
        this.state = {
            arrSchool: []
        };
    }
    componentWillMount() {
          this.getData();       
            this.listener = EventRegister.addEventListener('updateFilter', (arrData) => {
                this.setState({ arrSchool: arrData });
                this.forceUpdate();
            });       
    }

    getData() {
        Database.fetchListFromDB('School', (flag, data) => {
            if (flag) {
                this.setState({ arrSchool: data });
            }
        });
    }

    _renderTitleIndicator() {
        var title = ['All'];
        this.state.arrSchool.map((data) => {
            title.push(data.name);
        });
        return <PagerTitleIndicator titles={title}
            itemTextStyle={{ color: '#84A0AE', fontSize: responsiveFontSize(2.3), fontStyle: 'normal', fontFamily: 'Proxima Nova', }}
            selectedItemTextStyle={{ color: '#2D2D2D', fontSize: responsiveFontSize(2.3), fontStyle: 'normal', fontFamily: 'Proxima Nova', }}
            selectedBorderStyle={{ backgroundColor: '#2D2D2D', height: 2 }}
            trackScroll={true}

        />;
    }
    renderNewsListView() {
        return this.state.arrSchool.map((rowData) => {
            return (
                <View style={{ flex: 1, backgroundColor: 'pink' }}>
                     <NewsLettersList isAll={false} data={rowData} />
                </View>     
            );
        });
    }
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'white' }}>
                {Common.addNavTitle('Newsletters')}
                <View style={{ flex: 1, backgroundColor: 'transparent' }}>
                    <IndicatorViewPager
                        style={{ flex: 1, backgroundColor: 'white' }}
                        indicator={this._renderTitleIndicator()}
                    >
                    <View style={{ flex: 1, backgroundColor: 'pink' }}>
                        <NewsLettersList isAll data={this.state.arrSchool} />
                        </View>
                        {this.renderNewsListView()}
                    </IndicatorViewPager>
                </View>
            </View>
        );
    }

}
export default NewsLetters;
