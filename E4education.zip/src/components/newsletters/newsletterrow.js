import React from 'react';
import { View, Text } from 'react-native';
import { responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import * as Database from '../../database';
import ElevatedView from 'react-native-elevated-view';

var moment = require('moment');
var Color = require('color');
var createReactClass = require('create-react-class');
var striptags = require('striptags');

var NewsLetterRow = createReactClass({
    
    setCollor() {
        if (this.props.rowData.siteid !== undefined) {
            Database.fetchDataWithIdFromDB('School', 'siteid = "' + this.props.rowData.siteid + '"', (flag, data) => {
                if (flag) {
                    if (data.length > 0) {
                        this.props.rowData.colour = data[0].colour;
                        this.props.rowData.name = data[0].name;
                        this.props.rowData.website = data[0].website;
                    }
                } 
            });
        }        
    },


    render: function () {

        return (
            <ElevatedView 
            elevation={3}
             style={{ flex: 1, backgroundColor: 'white', marginTop: 10, marginLeft: 10, marginRight: 10,

            shadowOffset: { width: 1.5, height: 1.5 },
            shadowColor: 'gray', 
            shadowOpacity: 1.0,
            marginBottom: 10, }}>
            {this.setCollor()}
                <View style={{ flex: 1,}}>
                    <View style={{ flex: 1, width: null, backgroundColor: 'transparent', flexDirection: 'row' }}>
                   
                        <View style={{ width: responsiveWidth(25.0), height: responsiveWidth(25.0), backgroundColor: Color(this.props.rowData.colour).alpha(1.0).lighten(0), justifyContent: 'center', alignItems: 'center' }} >
                            <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', marginLeft: responsiveWidth(4.0), marginRight: responsiveWidth(4.0), textAlign: 'center', fontSize: responsiveFontSize(2.0), color: 'white' }}>{moment.unix(this.props.rowData.date).format("DD MMM YYYY").toUpperCase()}</Text>
                        </View>
                        <View style={{ flex: 1, height: responsiveWidth(25.0), width: null, backgroundColor: Color(this.props.rowData.colour).alpha(1.0).lighten(0.1), justifyContent: 'center' }} >
                            <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: 'white', fontSize: responsiveFontSize(2.5), fontWeight: '600', marginLeft: responsiveWidth(3.0), marginTop: 10 }} >{striptags(this.props.rowData.title)}</Text>
                            <Text style={{ fontStyle: 'normal', fontFamily: 'Proxima Nova', color: '#8F9BA8', fontSize: responsiveFontSize(2), marginLeft: responsiveWidth(3.0), height: responsiveWidth(5), marginTop: 5 }} >{striptags(this.props.rowData.name)}</Text>

                        </View>
                    </View>

                </View>
            </ElevatedView>
        );
    }
});

export default NewsLetterRow;
