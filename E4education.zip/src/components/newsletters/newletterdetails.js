import React, { Component } from 'react';
import { View, WebView, ScrollView, Dimensions, BackHandler } from 'react-native';
import HTML from 'react-native-render-html';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common'; 


class NewsLettersDetails extends Component {
    componentWillMount(){
        BackHandler.addEventListener('hardwareBackPress', () => {
                 Actions.pop();
            return true;
        });
    }
    componentDidUpdate(){
        BackHandler.removeEventListener('hardwareBackPress');
    }
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: '#F1F5F8' }}>
                {Common.addNavTitleWithback('Newsletters')}
                <ScrollView style={{ flex: 1 }}>
                <HTML html={this.props.data.body} imagesMaxWidth={Dimensions.get('window').width} />
            </ScrollView>
                {/* <WebView source={{ html: this.props.data.body }} style={{ flex: 1 }} /> */}
            </View>
        );
    }

}

export default NewsLettersDetails;
