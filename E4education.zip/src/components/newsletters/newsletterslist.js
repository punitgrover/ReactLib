import React, { Component } from 'react';
import { View, TouchableHighlight, FlatList } from 'react-native';
import { responsiveWidth, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { RNProgressHUD } from 'react-native-simplest-hud';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import { NoSalonView } from '../common';
import logo from '../../Images/iTunesArtwork.png';
import { fetchSchoolNewsLetters } from '../../services/school';
import NewsLetterRow from './newsletterrow';
import SharedManager from '../../common/sharedmanager';

class NewsLettersList extends Component {

  constructor(props) {
    super(props);
    this.arrNewsLetters = [];
    this.state = {
      isLoading: true,
      refreshing: false,
      data: []
    };
    this.onBackButtonAction = this.onBackButtonAction.bind(this);
    this.onSideMenuPress = this.onSideMenuPress.bind(this);
    this.onPressRefresh = this.onPressRefresh.bind();
  }
  componentWillMount() {
    this.getData();
  }
  componentWillReceiveProps() {
    this.setState({
      isLoading: true,
    });
    this.getData();
  }

  getData() {
    this.setState({
      isLoading: true,
    });
    if (this.props.isAll === true) {
      const arrSchool = [];
     var arrData = [];
     try {
      arrData = Array.prototype.slice.apply(this.props.data);
      arrData.map((item) => {
        arrSchool.push({ siteid: item.siteid, lastupdated: 0 });
      });
     }catch(error){

     }     
      this.callSchoolNewsLettersApi({ device: SharedManager.getInstance().getDeviceID(), schools: arrSchool });
    } else {
     try {
      this.callSchoolNewsLettersApi({ device: SharedManager.getInstance().getDeviceID(), schools: [{ siteid: this.props.data.siteid, lastupdated: 0 }] });
     }catch(error){      
     }
    }
  }

  callSchoolNewsLettersApi(postValue) {

    fetchSchoolNewsLetters(postValue, (flag, response, msg) => {
      if (flag) {
        SharedManager.getInstance().setDeviceID(response.api_deviceid);
        this.arrNewsLetters = [];
        response.schools.map((newsletters) => {
          this.arrNewsLetters = this.arrNewsLetters.concat(newsletters.newsletters
          );
        });
        this.arrNewsLetters = this.arrNewsLetters.filter(function(item){
          return item.action !== 'remove';
       });
      } else {
        Common.showAlertWithDefaultTitle(msg);
      }
      this.updateSchoolList();
    });
  }
  updateSchoolList() {
    this.setState({
      isLoading: false,
      refreshing: false,
      data: this.arrNewsLetters,
    });
  }
  onPressRefresh(){
    this.getData();
  }

  onSideMenuPress() {
    Actions.main();
  }
  onBackButtonAction() {
    Actions.pop();
  }
  onPressRow(rowData) {
      Actions.newletterdetail({ data: rowData });
  }

  onEndReached() {
  }
  onRefresh() {
    this.setState({refreshing: true,
      isLoading: true,
    });
    this.getData();
    }
  renderRow(rowData) {
    return (
      <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => this.onPressRow(rowData)}>
        <View style={styles.style_row_view}>
          <NewsLetterRow {...rowData} rowData={rowData} />
        </View>
      </TouchableHighlight>
    );
  }
  checkData() {
    if (this.arrNewsLetters.length === 0 && !this.state.isLoading) {
      return (
        <NoSalonView
          imageName={logo}
          message='No Newsletters Published'
          onPressRefresh={() => this.getData()}
        />
      );
    } else {
      return (
        <FlatList
              onRefresh={() => this.onRefresh()}
              refreshing={this.state.refreshing}
              removeClippedSubviews={false}
              legacyImplementation
              keyExtractor={(item, index) => item.id}
              data={this.state.data}
              renderItem={({ item }) => (
              this.renderRow(item)
              )}
        />
      );
    }
  }

  render() {   
    return (
      <View style={{ flex: 1, backgroundColor: '#F1F5F8', width: responsiveScreenWidth(100) }}>
        {this.checkData()}
        <RNProgressHUD
          isVisible={this.state.isLoading}
          color='#434c54'
          label='Loading'
          isActivityIndicator
        />
      </View>
    );
  }

}

const styles = {

  style_row_view: {
    flex: 1,
     },
  filerStyle: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    width: responsiveWidth(14),
    height: responsiveWidth(14),
    backgroundColor: 'transparent',
    alignItems: 'center',
    justifyContent: 'center',

  }
};
export default NewsLettersList;
