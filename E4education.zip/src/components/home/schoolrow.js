import React from 'react';
import { View, Text, Image } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import * as Database from '../../database';
import ElevatedView from 'react-native-elevated-view';

const createReactClass = require('create-react-class');

const SchoolRow = createReactClass({

    renderImage() {
        const str = this.props.rowData.thumbnail;
        const url = str.replace('  ', '%20');
        return (
            <Image source={{ uri: url }} style={{ flex: 1, backgroundColor: 'transparent', margin: 20 }} resizeMode='contain' />
        );
    },
    renderBlankView() {
        return (
            <View style={{ flex: 1, backgroundColor: 'transparent' }} />
        );
    },

    renderCheckImage() {
        Database.fetchDataWithIdFromDB('School', 'id = "' + this.props.rowData.id + '"', (flag, object) => {
            if (flag) {
                if (object.length > 0) {
                    this.props.rowData.isSelected = true;
                } else {
                    this.props.rowData.isSelected = false;
                }
            } else {
                this.props.rowData.isSelected = false;
            }
        });
        if (this.props.rowData.isSelected) {
            return (
                <View style={{ flex: 1, width: responsiveScreenWidth(10.0), height: responsiveScreenWidth(10.0), backgroundColor: '#13AAEB', borderRadius: responsiveScreenWidth(5.0), justifyContent: 'center', alignItems: 'center' }} >
                    <Image source={require('../../Images/icon_check.png')} style={{ width: responsiveScreenWidth(3), height: responsiveScreenWidth(3), backgroundColor: 'transparent', resizeMode: 'contain' }} />
                </View>
            );
        } else {
            return (
                <View style={{ flex: 1, width: responsiveScreenWidth(10.0), height: responsiveScreenWidth(10.0), backgroundColor: '#5F7282', borderRadius: responsiveScreenWidth(5.0), justifyContent: 'center', alignItems: 'center' }} >
                    <Image source={require('../../Images/icon_add.png')} style={{ width: responsiveScreenWidth(3), height: responsiveScreenWidth(3), backgroundColor: 'transparent', resizeMode: 'contain' }} />
                </View>
            );
        }
    },
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'transparent', marginTop: 10, marginLeft: 5, marginRight: 5, }}>
                <View style={{ flex: 1, position: 'relative' }} >
                    <ElevatedView
                        elevation={3}
                        style={{
                            flex: 1,
                            marginTop: responsiveScreenWidth(3.0),
                            marginLeft: responsiveScreenWidth(3.0),
                            marginRight: responsiveScreenWidth(3.0),
                            position: 'relative',
                            marginBottom: 10,
                        }}>
                        <View style={{ flex: 1, width: null, backgroundColor: 'transparent', flexDirection: 'row' }}>
                            <View style={{ width: responsiveScreenWidth(35.0), height: responsiveScreenWidth(35.0), backgroundColor: this.props.rowData.colour }} >
                                {this.props.rowData.thumbnail !== null ? this.renderImage() : this.renderBlankView()}
                            </View>
                            <View style={{ flex: 1, height: responsiveScreenWidth(35.0), width: null, backgroundColor: 'white', justifyContent: 'center', alignContent: 'center' }} >
                                <Text style={{ color: '#444A4E', fontSize: responsiveFontSize(2.2), fontWeight: '600', marginLeft: responsiveScreenWidth(3.0), marginTop: 15, fontStyle: 'normal', fontFamily: 'Proxima Nova', }} >{this.props.name}</Text>
                                <Text style={{ color: '#8F9BA8', fontSize: responsiveFontSize(2), marginLeft: responsiveScreenWidth(3.0), marginTop: responsiveScreenWidth(4.5), fontStyle: 'normal', fontFamily: 'Proxima Nova', }} >{this.props.locality}</Text>
                                <Text style={{ color: '#8F9BA8', fontSize: responsiveFontSize(2), marginLeft: responsiveScreenWidth(3.0), marginBottom: 15, fontStyle: 'normal', fontFamily: 'Proxima Nova', }} >{this.props.postcode}</Text>
                            </View>
                        </View>

                    </ElevatedView>
                </View>
                <ElevatedView elevation={3} style={{ flex: 0, alignSelf: 'flex-end', position: 'absolute', backgroundColor: 'transparent' }} >
                    {this.renderCheckImage()}
                </ElevatedView>
            </View>
        );
    }
});

export default SchoolRow;
