import React, { Component } from 'react';
import { View, Image, Text, TextInput, TouchableHighlight, Keyboard, TouchableWithoutFeedback, Platform, BackHandler, } from 'react-native';
import { responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import SplashScreen from 'react-native-splash-screen'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Geocoder from 'react-native-geocoder';
import LocationServicesDialogBox from 'react-native-android-location-services-dialog-box';
import ElevatedView from 'react-native-elevated-view';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import bgImage from '../../Images/backgroundImage.png';


const Permissions = require('react-native-permissions').default;

class Home extends Component {
    constructor(props) {
        super(props);
        this.state = ({
            postcode: '',
            validate: () => {
                let message = '';
                if (this.state.postcode === '') {
                    message = 'Please enter school name or post code.';
                }
                if (message === '') {
                    return true;
                }
                Common.showAlertWithDefaultTitle(message);
                return false;
            }
        });
    }
    componentWillMount() {
        BackHandler.addEventListener('hardwareBackPress', () => {
            Actions.pop();
            return true;
        });
    }
    componentDidMount() {
        SplashScreen.hide();
        if (Platform.OS !== 'ios') {
            LocationServicesDialogBox.checkLocationServicesIsEnabled({
                message: "<h2>Use Location ?</h2>This app wants to change your device settings.:<br/><br/>Use GPS, Wi-Fi, and cell network for location.<br/><br/>",
                ok: "YES",
                cancel: "NO",
                enableHighAccuracy: true, // true => GPS AND NETWORK PROVIDER, false => ONLY GPS PROVIDER 
                showDialog: true // false => Opens the Location access page directly 
            }).then(function (success) {
                setTimeout(
                    () => {
                        this.getLocation();
                    },
                    0
                );

            }.bind(this)
                ).catch((error) => {
                });
            BackHandler.addEventListener('hardwareBackPress', () => {
                LocationServicesDialogBox.forceCloseDialog();
            });
        } else {
            this.getLocation();
        }
    }
    getLocation() {
        navigator.geolocation.getCurrentPosition((position) => {
            this.latitude = position.coords.latitude;
            this.longitude = position.coords.longitude;
            this.getPostCode(this.latitude, this.longitude);
        }, error => console.log('error', error), { enableHighAccuracy: false, timeout: 20000, maximumAge: 1000 });
    }
    getPostCode(late, long) {
        Geocoder.geocodePosition({ lat: late, lng: long }).then(res => {
            this.setState({ postCode: res[0].postalCode, currentPostcode: res[0].postalCode });
        });
    }
    onSearch() {
        if (this.state.validate()) {
            this.setState({
                isLoading: true
            });
            Actions.schoolList({ postcode: this.state.postcode, lat: undefined, long: undefined, isPostcode: true });
        }
    }
    onSearchByNearMe() {
        Permissions.check('location').then(response => {
            if (response !== 'authorized') {
                Common.showAlertWithDefaultTitle('Please allow location access in your settings');
            } else {
                if (this.latitude !== undefined && this.longitude !== undefined) {
                    Actions.schoolList({ postcode: undefined, lat: this.latitude, long: this.longitude, isPostcode: false });
                } else {
                    this.getLocation();
                }
            }
        });
    }

    render() {
        return (
            <View style={{ backgroundColor: 'white', flex: 1 }}>
                {Common.addNavTitleWithback('Find my school')}
                <Image style={{ flex: 1, width: null, height: null, resizeMode: 'stretch' }} source={bgImage} />
                <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
                    <View style={{ flex: 1, position: 'absolute', top: 44, bottom: 0, left: 0, right: 0 }}>
                        <KeyboardAwareScrollView style={{ backgroundColor: 'transparent' }} resetScrollToCoords={{ x: 0, y: 0 }} scrollEnabled automaticallyAdjustContentInsets={false} keyboardShouldPersistTaps="always" >
                            <View style={{ flex: 1 }}>
                                <Text style={{ flex: 1, marginTop: responsiveWidth(10.0), color: 'black', fontSize: responsiveFontSize(4.0), textAlign: 'center', fontStyle: 'normal', fontFamily: 'Proxima Nova', fontWeight: '600' }}> Let's get started! </Text>
                                <Text style={{ flex: 1, marginTop: responsiveWidth(10.0), marginLeft: responsiveWidth(10.0), marginRight: responsiveWidth(10.0), color: '#8B9AA5', fontSize: responsiveFontSize(2.2), textAlign: 'center', fontStyle: 'normal', fontFamily: 'Proxima Nova', fontWeight: '400' }}>
                                    Click the button below to find schools near your current location
                      </Text>
                                <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ flex: 1 }} onPress={() => this.onSearchByNearMe()}>
                                    <View style={{
                                        flex: 1, backgroundColor: 'white',
                                        marginTop: responsiveWidth(10.0),

                                        marginLeft: responsiveWidth(8.0),
                                        marginRight: responsiveWidth(8.0),
                                        height: responsiveWidth(15.0),
                                        alignItems: 'center',
                                        justifyContent: 'center',

                                        borderRadius: responsiveWidth(7.5),

                                    }}>
                                        <ElevatedView
                                            elevation={3}
                                            style={{
                                                flex: 1,
                                                marginTop: 2,
                                                marginBottom: 2,
                                                flexDirection: 'row',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                backgroundColor: '#0E51B9',
                                                borderRadius: responsiveWidth(7.5),
                                                shadowOffset: { width: 1.5, height: 1.5 },
                                                shadowColor: 'gray',
                                                shadowOpacity: 1.0,
                                                elevation: 2
                                            }}
                                        >
                                            <View style={{ width: responsiveWidth(15.0), height: responsiveWidth(15.0), backgroundColor: 'transparent', alignItems: 'center', justifyContent: 'center', }}>
                                                <Image source={require('../../Images/find_school.png')} style={{ width: responsiveWidth(6.0), height: responsiveWidth(6), backgroundColor: 'transparent', resizeMode: 'contain' }} />
                                            </View>
                                            <View style={{ flex: 1, height: responsiveWidth(15.0), backgroundColor: 'transparent', justifyContent: 'center' }} >
                                                <Text style={{ color: 'white', fontSize: responsiveFontSize(2.2), fontWeight: '500', textAlign: 'center', backgroundColor: 'transparent', marginRight: responsiveWidth(6), fontStyle: 'normal', fontFamily: 'Proxima Nova', }}>
                                                    FIND SCHOOLS NEAR ME
                            </Text>
                                            </View>
                                        </ElevatedView>
                                    </View>
                                </TouchableHighlight>
                                <View
                                    style={{
                                        marginTop: responsiveWidth(10.0),
                                        flexDirection: 'row',
                                        marginLeft: responsiveWidth(8.0),
                                        marginRight: responsiveWidth(8.0),
                                        height: responsiveWidth(7.0),
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        backgroundColor: 'transparent'
                                    }}
                                >
                                    <View style={{ flex: 1, height: 1.0, backgroundColor: '#AABDC9' }} />
                                    <Text style={{ marginLeft: 10, color: '#AABDC9', fontSize: responsiveFontSize(2.2), fontWeight: '500', fontStyle: 'normal', fontFamily: 'Proxima Nova', }}>
                                        OR
                            </Text>
                                    <View style={{ flex: 1, height: 1.0, backgroundColor: '#AABDC9', marginLeft: 10 }} />
                                </View>
                                <View

                                    style={{
                                        marginTop: responsiveWidth(10.0),
                                        flexDirection: 'row',
                                        marginLeft: responsiveWidth(8.0),
                                        marginRight: responsiveWidth(8.0),
                                        height: responsiveWidth(15.0),
                                        backgroundColor: 'white',
                                        borderRadius: responsiveWidth(7.5),

                                    }}
                                >
                                    <TextInput style={{ flex: 1, backgroundColor: 'transparent', marginLeft: 20, marginRight: 0, marginBottom: 5, marginTop: 5, fontSize: responsiveFontSize(1.9), fontWeight: '600' }}
                                        autoCorrect={false}
                                        placeholder='Find a school by name or postcode'
                                        underlineColorAndroid={'transparent'}
                                        placeholderTextColor="#C6C6C6"
                                        value={this.state.postcode}
                                        onChangeText={postcode => this.setState({ postcode })}
                                    />
                                    <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ width: responsiveWidth(10.0), height: responsiveWidth(10.0), backgroundColor: 'transparent', justifyContent: 'center', alignItems: 'center', alignSelf: 'center', marginRight: 10 }} onPress={() => this.onSearch()}>
                                        <View style={{ flex: 1, backgroundColor: 'transparent', justifyContent: 'center', alignItems: 'center', marginRight: 0 }} >
                                            <Image source={require('../../Images/search.png')} style={{ width: responsiveWidth(6.0), height: responsiveWidth(6), backgroundColor: 'transparent', resizeMode: 'contain' }} />
                                        </View>
                                    </TouchableHighlight>
                                </View>
                            </View>
                        </KeyboardAwareScrollView>

                    </View>
                </TouchableWithoutFeedback>
            </View>
        );
    }

}

export default Home;
