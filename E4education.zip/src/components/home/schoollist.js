import React, { Component } from 'react';
import { View, Text, FlatList, TouchableHighlight, BackHandler } from 'react-native';
import { responsiveWidth, responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { EventRegister } from 'react-native-event-listeners';
import { RNProgressHUD } from 'react-native-simplest-hud';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import { NoSalonView } from '../common';
import logo from '../../Images/iTunesArtwork.png';
import { fetchSchoolList, fetchSchoolCategories, fetchSchoolListByLocation } from '../../services/school';
import SharedManager from '../../common/sharedmanager';
import SchoolRow from './schoolrow';
import * as Database from '../../database';

class SchoolList extends Component {

    constructor(props) {
        super(props);
        this.arrSchool = [];
        this.count = 1;
        this.radius = 5;
        this.latitude = 0.0;
        this.longitude = 0.0;
        this.isPostcode = true;
        this.state = {
            isLoading: true,
            data: [],
            isShowBuutton: false
        };
        this.onBackButtonAction = this.onBackButtonAction.bind(this);
    }
    componentWillMount() {
        BackHandler.addEventListener('hardwareBackPress', () => {
            Actions.pop();
            return true;
        });
        this.postcode = this.props.postcode;
        this.isPostcode = this.props.isPostcode;
        this.latitude = this.props.lat;
        this.longitude = this.props.long;
        this.titleMessage = 'Showing results for }<b>{{this.state.postcode}}</b>';
       this.getData();
    }

    getData() {
        const deviceID = SharedManager.getInstance().getDeviceID();
        const postValue = {
            device: deviceID,
        };
        this.setState({ isLoading: true });
        if (this.isPostcode === true) {
            this.callSchoolApi(postValue);
        } else {
            this.callSchoolByLocationApi(postValue);
        }
    }

    callSchoolByLocationApi(postValue) {
        var urlParameter = `/${this.longitude}/${this.latitude}/${this.radius}`;
        fetchSchoolListByLocation(postValue, urlParameter, (flag, response, msg) => {
            if (flag) {
                SharedManager.getInstance().setDeviceID(response.did);
                this.arrSchool = response.schools;
                this.count = response.count;

            } else {
                Common.showAlertWithDefaultTitle(msg);
            }
            this.updateSchoolList();
        });
    }

    callSchoolApi(postValue) {
        var urlParameter = '';
        if (this.isPostcode !== undefined && this.isPostcode === false) {
            urlParameter = this.latitude + this.longitude + '/' + this.radius;
        }
        else {
            urlParameter = this.postcode.replace(' ', '%20') + '/' + this.radius;
        }
        fetchSchoolList(postValue, urlParameter, (flag, response, msg) => {
            if (flag) {
                SharedManager.getInstance().setDeviceID(response.did);
                this.arrSchool = response.schools;
                this.count = response.count;
            } else {
                Common.showAlertWithDefaultTitle(msg);
            }
            this.updateSchoolList();
        });
    }
    updateSchoolList() {
        this.setState({
            data: this.arrSchool,
            isLoading: false
        });
    }

    onBackButtonAction() {
        Actions.pop();
    }
    deleteSchoolFromDB(object) {
        try {
            Database.realm.write(() => {
                Database.realm.delete(object);
                this.updateSchoolList();
            });

        } catch (error) {
            Common.showAlertWithDefaultTitle(JSON.stringify(error));
        }
    }
    onPressRow(rowData) {
        if (rowData.isSelected === true) {
            Database.fetchDataWithIdFromDB('School', 'id = "' + rowData.id + '"', (flag, object) => {
                if (flag) {
                    this.deleteSchoolFromDB(object[0]);
                }
            });
        } else {
            this.setState({
                isLoading: true
            });
            this.callSchoolCategories({ device: SharedManager.getInstance().getDeviceID(), schools: [{ siteid: rowData.siteid, lastupdated: 0 }] }, rowData);
        }

    }
    callSchoolCategories(postValue, rowData) {
        fetchSchoolCategories(postValue, (flag, response, msg) => {
            if (flag) {
                SharedManager.getInstance().setDeviceID(response.api_deviceid);
                response.schools.map((categories) => {
                    this.filterData(categories.categories, rowData);
                });
            }
            else {
                this.updateSchoolList();
                Common.showAlertWithDefaultTitle(msg);
            }
        });
    }

    filterData(categories, rowData) {

        if (Object.keys(categories).length > 0) {
            if (Object.keys(categories.news).length > 0) {
                const news = [];
                for (var k in categories.news) {
                    if (categories.news.hasOwnProperty(k)) {
                        news.push(k);
                    }
                }
                rowData.newscategories = news.join();
            }

            if (Object.keys(categories.events).length > 0) {
                const events = [];
                for (var k in categories.events) {
                    if (categories.events.hasOwnProperty(k)) {
                        events.push(k);
                    }
                }
                rowData.eventscategories = events.join();
            }

            if (Object.keys(categories.albums).length > 0) {
                const albums = [];
                for (var k in categories.albums) {
                    if (categories.albums.hasOwnProperty(k)) {
                        albums.push(k);
                    }
                }
                rowData.albumscategories = albums.join();
            }
            Database.saveTODB('School', rowData, (flag) => {
                if (flag) {
                    this.updateSchoolList();
                }
            });
        } else {
            rowData.newscategories = '';
            rowData.eventscategories = '';
            rowData.albumscategories = '';
            Database.saveTODB('School', rowData, (flag) => {
                if (flag) {
                    this.updateSchoolList();
                }
            });
            this.updateSchoolList();
        }
    }


    onEndReached() {
        this.radius = this.radius + 5;
        const deviceID = SharedManager.getInstance().getDeviceID();
        const postValue = {
            device: deviceID,
        };
        this.setState({ isLoading: true });
        if (this.isPostcode === true) {
            this.callSchoolApi(postValue);
        } else {
            this.callSchoolByLocationApi(postValue);
        }
    }
    renderRow(rowData) {
        return (
            <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => this.onPressRow(rowData)}>
                <View style={styles.style_row_view}>
                    <SchoolRow {...rowData} rowData={rowData} />
                </View>
            </TouchableHighlight>
        );
    }

    renderButton() {
        var arrData = [];
        Database.fetchListFromDB('School', (flag, object) => {
            if (flag) {
                arrData = object;
            }
        });
        if (arrData.length > 0) {
            return (
                <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' onPress={() => EventRegister.emit('setTab', true)}>
                    <View style={{ backgroundColor: '#13AAEB', width: null, height: responsiveScreenWidth(12), alignItems: 'center', justifyContent: 'center' }} >
                        <Text style={{ color: 'white', textAlign: 'center', fontSize: responsiveFontSize(2), fontWeight: '600', fontStyle: 'normal', fontFamily: 'Proxima Nova', }}>OK, I'M FINISHED</Text>
                    </View>
                </TouchableHighlight>
            );
        } else {
            return (
                <View
                    style={{ backgroundColor: '#F1F5F8', width: null, height: 0 }}
                />
            );
        }
    }
    checkData() {
        if (this.arrSchool.length === 0 && !this.state.isLoading) {
            return (
                <NoSalonView
                    imageName={logo}
                    message='No schools were found near your location'
                    onPressRefresh={() => this.getData()}
                />
            );
        } else {
            return (
                <FlatList
                    style={{ flex: 1, backgroundColor: '#F1F5F8' }}
                    onEndReachedThreshold={0.5}
                    onEndReached={({ distanceFromEnd }) => {
                        this.onEndReached();
                    }}
                    removeClippedSubviews={false}
                    data={this.state.data}
                    renderItem={({ item }) => (
                        this.renderRow(item)
                    )}
                />
            );
        }
    }

    render() {
        return (
            <View style={{ backgroundColor: '#F1F5F8', flex: 1 }}>
                {Common.addNavTitleWithback('Select a school')}
                <View style={{ backgroundColor: 'transparent' }}>
                    <Text style={{ margin: 10, backgroundColor: '', textAlign: 'center', fontSize: responsiveFontSize(2.2), color: '#909EAA', fontStyle: 'normal', fontFamily: 'Proxima Nova', }}>
                        Showing results for
                  <Text style={{ backgroundColor: 'transparent', textAlign: 'center', fontSize: responsiveFontSize(2.2), fontWeight: '700', color: '#6C7D8C', fontStyle: 'normal', fontFamily: 'Proxima Nova', }}> {this.postcode} </Text>
                    </Text>
                </View>
                <View style={{ backgroundColor: '#EBF0F4', height: 1 }} />
                <View style={{ backgroundColor: 'transparent' }}>
                    <Text style={{ margin: 15, backgroundColor: 'transparent', textAlign: 'center', fontSize: responsiveFontSize(2.0), color: '#909EAA', fontStyle: 'normal', fontFamily: 'Proxima Nova', }}>
                        To subscribe to updates from a school, please touch the + next to the school
                  </Text>
                </View>
                {this.checkData()}
                {this.renderButton()}

                <RNProgressHUD
                    isVisible={this.state.isLoading}
                    color='#434c54'
                    label='Loading'
                    isActivityIndicator
                />

            </View>
        );
    }

}

const styles = {

    style_row_view: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '#F1F5F8',
    },
};
export default SchoolList;
