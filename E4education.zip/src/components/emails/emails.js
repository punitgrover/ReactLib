import React, { Component } from 'react';
import { View } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { IndicatorViewPager, PagerTitleIndicator } from 'rn-viewpager';
// import { fetchSchoolListFromDB } from '../../database/databaseengin';
import * as Database from '../../database';
import * as Common from '../../common';
import EmailList from './emaillist';
import { Actions } from 'react-native-router-flux';

class Emails extends Component {

    constructor(props) {
        super(props);        
        this.state = {
            arrSchool: []
        };
       
    } 

    componentWillMount() {  
      Database.fetchListFromDB('School', (flag, data) =>{
        if (flag) {
          this.setState({ arrSchool: data }); 
            }
    });

      // fetchSchoolListFromDB((flag, data) => {
      //     if (flag) {
      //      this.setState({ arrSchool: data }); 
      //     }
      // });        
    }

    componentDidMount() {
      //  Actions.userlogin();
    }  

    _renderTitleIndicator() {

      var title = ['All'];
       this.state.arrSchool.map((data) => {
         title.push( data.name);
      });

      return <PagerTitleIndicator titles={title}
      itemTextStyle={{ color: '#84A0AE', fontSize: responsiveFontSize(2.8) }}
      selectedItemTextStyle={{ color: '#2D2D2D', fontSize: responsiveFontSize(2.8) }}
      selectedBorderStyle={{ backgroundColor: '#2D2D2D', height: 2 }}
      
      />;
  }
  renderNewsListView() {
   return this.state.arrSchool.map((rowData) => {
      return (
        <EmailList data={rowData}  />  
      );
    });
  }
    render() {
       return (
            <View style={{flex: 1, backgroundColor: 'white'}}>
                {Common.addNavTitle('Emails')}
                <View style={{ flex: 1, backgroundColor: 'transparent'}}>
                  <IndicatorViewPager
					        style={{ flex: 1, backgroundColor: 'white'}}
                    indicator={this._renderTitleIndicator()}
                >
                 <EmailList /> 
                {this.renderNewsListView()}
               
                </IndicatorViewPager>
                </View>               
      </View>
        );
    }

}

    export default Emails;
