import React from 'react';
import { View, Text, Image } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';

var createReactClass = require('create-react-class');
const timer = require('../../Images/time.png');

var EmailRow = createReactClass({
  
    renderCircle() {
        return(
            // <View style={{ backgroundColor: 'red', height: responsiveScreenWidth(5), width: responsiveScreenWidth(5), borderRadius: responsiveScreenWidth(2.5)}} />
            <View style={{ backgroundColor: 'white', height: responsiveScreenWidth(5), width: responsiveScreenWidth(5), borderRadius: responsiveScreenWidth(2.5), borderWidth: 3, borderColor: 'red'}} />
        );
    },   
 render: function() {
        //  debugger;
      return (
        <View style={{ flex: 1, backgroundColor: 'white', marginTop: 2, marginLeft: 5, marginRight: 5, flexDirection: 'row' }}>
          <View style={{ width: responsiveScreenWidth(10), backgroundColor: 'transparent', justifyContent: 'center', alignItems: 'center'}} >
            {this.renderCircle()}
          </View>
          <View style={{ flex: 3, backgroundColor: 'transparent',justifyContent: 'center'}}>
            <Text style={{ flex: 1, color: '#3D4449', fontSize: responsiveFontSize(2.2), fontWeight: '500', marginLeft: 10, marginTop: 10 }}>Parents Evening reminder</Text> 
            <Text style={{ flex: 1, color: '#3D4449', fontSize: responsiveFontSize(1.9), fontWeight: '200', marginLeft: 10, marginBottom: 10 }}>John Jones</Text>
          </View>  
          <View style={{ flex: 1, marginLeft: 5, marginRight: 5, marginTop: 5, backgroundColor: 'transparent', flexDirection: 'row', justifyContent: 'center' }} >
          <Image source={timer} style={{ width: responsiveScreenWidth(3), height: responsiveScreenWidth(3), backgroundColor: 'transparent', resizeMode: 'contain' }} />
          <Text style={{ color: '#B3C3D0', fontSize: responsiveFontSize(1.5), fontWeight: '500' }} > 11 NOV </Text>
          </View>
               
        </View>
      );
    }
    });

export default EmailRow;
