import React, { Component } from 'react';
import { View, Text, TouchableHighlight, Image, ScrollView } from 'react-native';
import { responsiveFontSize, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import * as Common from '../../common';

const timer = require('../../Images/time.png');

class EmailDetails extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        console.log('render..');
        return (
            <View style={{ flex: 1, backgroundColor: '#F1F5F8' }}>
                {Common.addNavTitleWithback('Emails')}
                <View style={{ flex: 1, backgroundColor: 'transparent' }} >
                    <Text style={{ backgroundColor: 'transparent', color: '#3A4045', fontSize: responsiveFontSize(3), marginTop: 20, marginLeft: 10, marginRight: 10, marginBottom: 10, fontWeight: '500' }}>Parents Eventing Reminder</Text>
                    <View style={{ flexDirection: 'row', marginLeft: 10, marginRight: 10, marginBottom: 5, backgroundColor: 'transparent' }}>
                        <Text style={{ flex: 2, color: '#B3C3D0', fontSize: responsiveFontSize(2), fontWeight: '200' }}>Bob Jones</Text>
                        <View style={{ flex: 1, marginLeft: 5, marginRight: 5, backgroundColor: 'transparent', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }} >
                            <Image source={timer} style={{ width: responsiveScreenWidth(3), height: responsiveScreenWidth(3), backgroundColor: 'transparent', resizeMode: 'contain' }} />
                            <Text style={{ color: '#B3C3D0', fontSize: responsiveFontSize(2), fontWeight: '200' }} > 14:00 - 15:30</Text>
                        </View>

                    </View>
                    <View style={{ width: null, height: 1, backgroundColor: 'gray' }} />
                    <ScrollView contentContainerStyle={{ paddingVertical: 20 }}>
                        <Text style={{ color: '#565B60', fontSize: responsiveFontSize(2), fontWeight: '200', marginLeft: 10, marginRight: 10 }} > What is Lorem Ipsum?
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

                        Why do we use it?
                        It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
                        What is Lorem Ipsum?
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

                        Why do we use it?
                        It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
                    </Text>
                    </ScrollView>
                    <View style={{ width: null, backgroundColor: 'transparent', flexDirection: 'row', height: responsiveScreenWidth(15), justifyContent: 'center', alignContent: 'center' }}>
                        <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ flex: 1 }} onPress={() => console.log('REPLY')}>
                            <View style={{ marginLeft: responsiveScreenWidth(3), marginTop: responsiveScreenWidth(2.5), marginBottom: responsiveScreenWidth(2.5), flex: 1, borderRadius: responsiveScreenWidth(5), backgroundColor: '#95ACBC', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                <Image source={require('../../Images/reply.png')} style={{ backgroundColor: 'transparent', marginLeft: 15, width: responsiveScreenWidth(4), height: responsiveScreenWidth(4), resizeMode: 'contain' }} />
                                <Text style={{ alignSelf: 'center', backgroundColor: 'transparent', color: 'white', fontSize: responsiveFontSize(1.8), fontWeight: '500', marginLeft: 3 }} > REPLY </Text>
                            </View>
                        </TouchableHighlight>
                        <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ flex: 1 }} onPress={() => console.log('FORWARD')}>
                            <View style={{ margin: responsiveScreenWidth(2.5), flex: 1, borderRadius: responsiveScreenWidth(5), backgroundColor: '#95ACBC', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                <Image source={require('../../Images/forward.png')} style={{ backgroundColor: 'transparent', width: responsiveScreenWidth(4), height: responsiveScreenWidth(4), resizeMode: 'contain' }} />
                                <Text style={{ alignSelf: 'center', backgroundColor: 'transparent', color: 'white', fontSize: responsiveFontSize(1.8), fontWeight: '500' }} > FORWARD </Text>
                            </View>
                        </TouchableHighlight>
                        <TouchableHighlight underlayColor='rgba(73,182,77,1,0.9)' style={{ flex: 1 }} onPress={() => console.log('DELETE')}>
                            <View style={{ marginRight: responsiveScreenWidth(3), marginTop: responsiveScreenWidth(2.5), marginBottom: responsiveScreenWidth(2.5), flex: 1, borderRadius: responsiveScreenWidth(5), borderWidth: 2, borderColor: '#95ACBC', backgroundColor: 'transparent', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                                <Image source={require('../../Images/delete.png')} style={{ backgroundColor: 'transparent', marginLeft: 15, width: responsiveScreenWidth(4), height: responsiveScreenWidth(4), resizeMode: 'contain' }} />
                                <Text style={{ alignSelf: 'center', backgroundColor: 'transparent', color: '#AEC5CB', fontSize: responsiveFontSize(1.8), fontWeight: '500', marginLeft: 3 }} > DELETE </Text>
                            </View>
                        </TouchableHighlight>


                    </View>

                </View>
            </View>
        );
    }

}

export default EmailDetails;
