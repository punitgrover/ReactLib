import React, { Component } from 'react';
import { View, TouchableHighlight, ListView } from 'react-native';
import { responsiveWidth, responsiveScreenWidth } from 'react-native-responsive-dimensions';
import { RNProgressHUD } from 'react-native-simplest-hud';
import { Actions } from 'react-native-router-flux';
import * as Common from '../../common';
import { NoSalonView } from '../common';
import logo from '../../Images/iTunesArtwork.png';
import { fetchSchoolList } from '../../services/school';
import EmailRow from './emailrow';

class EmailList extends Component {

    constructor(props) {
        super(props);
        this.arrSchool = [];
        this.count = 1;
        this.radius = 5;
        this.latitude = 0.0;
        this.longitude = 0.0;
        this.isPostcode = true;
       
        const ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => true });
        this.state = {
            dataSource: ds.cloneWithRows(this.arrSchool),
            isLoading: true,
            data: []
        };
         this.onBackButtonAction = this.onBackButtonAction.bind(this);
         this.onSideMenuPress = this.onSideMenuPress.bind(this);
    }
    componentWillMount() {
        this.postcode = 'pe2 6lr';
        this.isPostcode = true;
        this.latitude = this.props.lat;
        this.longitude = this.props.long;
        this.titleMessage = 'Showing results for }<b>{{this.state.postcode}}</b>';
       if (this.isPostcode === true) {
            const postValue = {
                device: 109501,
            };
            this.setState({ isLoading: true });
            this.callSchoolApi(postValue);
        } else {
            const postValue = {
                latitude: this.latitude,
                longitude: this.longitude,
            };
            this.callSchoolApi(postValue);
        }
    }

    callSchoolApi(postValue) {
        // `${BASE_URL}${methodName}`;
        var urlParameter = this.postcode.replace(' ', '%20') + '/' + this.radius;
        if (this.isPostcode !== true) {
            urlParameter = this.latitude + this.longitude + '/' + this.radius;
        }

        fetchSchoolList(postValue, urlParameter, (flag, response, msg) => {
            // debugger;
            if (flag) {
                // debugger;
                this.arrSchool = this.arrSchool.concat(response.schools);
                this.count = response.count;
              } else if (msg === Messages.NO_INTERNET) {
                Common.showAlertWithDefaultTitle(msg);
              }
             this.updateSchoolList();
        });
    }
    updateSchoolList() {
        // debugger;
        this.setState({
          dataSource: this.state.dataSource.cloneWithRows(this.arrSchool),
          isLoading: false
        });
      }
    onSideMenuPress() {
     Actions.main();
    }
    onBackButtonAction() {
      Actions.pop();
    }
    onPressRow(rowID, rowData) {
       Actions.emaildetails();
     }
    
    onEndReached() {
        // debugger;
        this.radius = this.radius + 5
        if (this.isPostcode === true) {
            const postValue = {
                device: 109501,
            };
            this.setState({ isLoading: true });
            this.callSchoolApi(postValue);
        } else {
            const postValue = {
                latitude: this.latitude,
                longitude: this.longitude,
            };
            this.callSchoolApi(postValue);
        }
    }
    renderRow(rowData, sectionID, rowID) {
       return (
          <TouchableHighlight onPress={() => this.onPressRow(rowID, rowData)}>
            <View style={styles.style_row_view}>
              <EmailRow {...rowData} key={rowData.id} rowData={rowData} />
            </View>
          </TouchableHighlight>
        );
      }
      checkData() {
        if (this.arrSchool.length === 0 && !this.state.isLoading) {
          return (
            <NoSalonView
              imageName={logo}
              message='No Record Found'
            />
          );
        } else {
          return (
            <ListView
            style={{ backgroundColor: '#F1F5F8' }}
            dataSource={this.state.dataSource}
            renderRow={this.renderRow.bind(this)}
            enableEmptySections
            onEndReached={this.onEndReached.bind(this)}
            onEndReachedThreshold={0}
            />
          );
        }
      }

    render() {
         return (
               <View style={{ backgroundColor: '#F1F5F8', width: responsiveScreenWidth(100) }}>
              
                {/* {Common.addNavTitle('Select a school', this.onSideMenuPress.bind(this))} */}
               
                {this.checkData()}
                
                 <RNProgressHUD
                     isVisible={this.state.isLoading}
                     color='#434c54'
                     label='Loading'
                     isActivityIndicator
                 />

            </View>
        );
    }

}

const styles = {
    
      style_row_view: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '#F1F5F8',
      },
      filerStyle: {
        //zIndex: 1,
        // zIndex: -100,
        //  position: 'absolute',
        // zIndex: 0,
        position: 'absolute',
        bottom: 8,
        right: 8,
        width: responsiveWidth(14),
        height: responsiveWidth(14),
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',
    
      }
    };
export default EmailList;
