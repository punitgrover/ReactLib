
import React from 'react';
import { Dimensions } from 'react-native';

//Base URL
export const BASE_URL = 'https://mobiledata.e4education.co.uk/3/';

export const PROJECTNAME = 'E4education';
export const EMAILREG = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
export const PASSWORDREG = /^\S{3,}$/;
export const GOOGLEKEY = 'AIzaSyAeHbHwrOUCerQ-UVL7x4KOG5B66LRVeUM';
export const GOOGLEMAPURL = 'https://maps.google.com/maps/api/geocode/json';
export const ApiMethods = {
    NEAR_POSTCODE: 'school/nearPostcode/',
    NEAR_BYLOCATION: 'school/byLocation',
    NEWS: 'news/',
    NEWS_LETTERS: 'newsletters/',
    EVENT: 'events/',
    ALBUMS: 'albums/',
    PLACE: 'pages',
    CATEGPRIES: 'categories',
   
};

export const Messages = {
    SERVER_ERROR: 'Something went wrong, please try again.',
    POSTCODE_BLANK_ERROR: 'Please enter postcode.',
    NO_INTERNET: 'No internet, please check your internet.'
};  

export const screenSize = {
    WIDTH: Dimensions.get('window').width,
    HEIGHT: Dimensions.get('window').height
};

