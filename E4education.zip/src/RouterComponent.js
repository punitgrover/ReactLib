import React, { Component } from 'react';
import { StatusBar, Text, View, StyleSheet, PixelRatio } from 'react-native';
import {Router, Scene, Route, Actions, ActionConst } from 'react-native-router-flux';
import { EventRegister } from 'react-native-event-listeners';
import Home from './components/home/home';
import SchoolList from './components/home/schoollist';
import News from './components/news/news';
import Events from './components/events/events';
import Emails from './components/emails/emails';
import NewsLetters from './components/newsletters/newsletters';
import More from './components/more/more';
import YourSchool from './components/yourschools/yourschools';
import Contact from './components/yourschools/contact';
import Settings from './components/yourschools/setting';
import NewsCategories from './components/yourschools/newscategories';
import Albums from './components/albums/albums';
import FullImage from './components/albums/fullimage'
import AlbumsList from './components/albums/albumsList';
import UserLogin from './components/user/user-login';
import EmailDetails from './components/emails/emaildetails';
import EventDetails from './components/events/eventdetail';
import NewsDetails from './components/news/newsdetails';
import MoreDetails from './components/more/moredetails';
import NewsLettersDetails from './components/newsletters/newletterdetails';
import { createIconSetFromFontello } from 'react-native-vector-icons';
import FontelloConfig from './config.json';
// import * as Database from '../../database';
import * as Database from './database';

 const Icon = createIconSetFromFontello(FontelloConfig);
// import Icon from 'react-native-vector-icons/FontAwesome';
 
 class TabIcon extends Component {
    render() {
        var color = this.props.focused ? '#363c41' : '#95acbc';
        return (
            <View style={{ flex: 1, flexDirection: 'column', alignItems: 'center', alignSelf: 'center', justifyContent: 'center' }}>
                <Icon style={{ color: color  }} name={this.props.iconName || "circle"} size={25} />
                {/* <Text style={{ color: color, fontSize: 12 }}>{this.props.title}</Text> */}
            </View>
        );
    }
}

class RouterComponent extends Component {

    constructor(props) {
        super(props);
        this.showTab = false;
        this.state = {
            isShowbarController: false
        };
        Database.fetchListFromDB('School', (flag, data) => {
            if (flag) {
                if (data.length > 0) {
                    this.showTab = true;
                    this.setState({ isShowbarController: true });
                }else{
                    this.showTab = false;
                    this.setState({ isShowbarController: false });
                }
            }
            else{
                this.showTab = false;
               this.setState({ isShowbarController: false });
            }
          });
   }
    componentWillMount() {
        this.listener = EventRegister.addEventListener('setScene', (flag) => {
           this.showTab = flag;
            this.setState({ isShowbarController: flag });
            // this.state = {
            //         isShowbarController: flag,
            //      };
             Actions.auth({type: 'reset'});    
            // Actions.postcodevc({ type: 'replace' });     
        });

        this.listenerTab = EventRegister.addEventListener('setTab', (flag) => {
            this.showTab = flag;
            this.setState({ isShowbarController: flag });
            // this.state = {
            //         isShowbarController: flag,
            //      };
            Actions.main({type: 'replace'});
            // Actions.refresh();    
            // Actions.postcodevc({ type: 'replace' });     
        });
    }

    render() {
           return (

            <Router key='roude'>   
             <Scene key='navigation'>            
                        <Scene type={ActionConst.RESET} key='auth'>  
                         {/* {this.checkController()}    */}
                      
                        {/* <Scene key="schoolList" component={SchoolList} hideNavBar panHandlers={null} title="Find my school" />                        */}
                            
                        <Scene type={ActionConst.REPLACE} tabs key="main" hideNavBar tabBarStyle={styles.tabBar} default="scene1" activeTintColor="#363c41" inactiveTintColor="#95acbc" wrap swipeEnabled={false} lazy animationEnabled={false} tabBarPosition='bottom' initial={this.showTab} >
                                <Scene title="News" hideNavBar iconName="news" key="scene1" initial component={News} icon={TabIcon} />
                                <Scene title="Events" hideNavBar iconName="event" key="scene2" type="switch" component={Events} icon={TabIcon} />
                                {/* <Scene title="Email" hideNavBar iconName="email" key="scene3" type="switch" component={Emails} icon={TabIcon} /> */}
                                <Scene title="Newsletters" hideNavBar iconName="newsletter" key="scene4" component={NewsLetters} icon={TabIcon} />
                                <Scene title="More" hideNavBar iconName="mehu" key="scene5" component={More} icon={TabIcon} /> 
                            </Scene> 
                             <Scene type={ActionConst.REPLACE} key="postcodevc" component={Home} hideNavBar panHandlers={null} title="Find my school" initial={!this.showTab} />
                            
                            <Scene key="schoolList" component={SchoolList} hideNavBar panHandlers={null} title="Find my school" />                            
                             
                            <Scene title="Your Schools" hideNavBar key="yourschool" component={YourSchool} /> 
                            <Scene title="Contact" hideNavBar key="contact" component={Contact} /> 
                            <Scene title="Settings" hideNavBar key="setting" component={Settings} /> 
                            <Scene title="NewsCategories" hideNavBar key="newscategories" component={NewsCategories} /> 
                            <Scene title="Album" hideNavBar key="albums" component={Albums} />
                            <Scene title="AlbumList" hideNavBar key="albumslist" component={AlbumsList} />
                            <Scene title="User Login" hideNavBar key="userlogin" component={UserLogin} />
                            <Scene title="Email" hideNavBar key="emaildetails" component={EmailDetails} />
                            <Scene title="News Details" hideNavBar key="newsdetails" component={NewsDetails} />
                            <Scene title="Events Details" hideNavBar key="eventdetails" component={EventDetails} />
                            <Scene title="Albums" hideNavBar key="fullImage" component={FullImage} />
                            <Scene title="MoreDetails" hideNavBar key="moredetails" component={MoreDetails} />
                            <Scene title="NewsLettersDetails" hideNavBar key="newletterdetail" component={NewsLettersDetails} />
                            
                        </Scene>
                  </Scene>      

            </Router>
          

        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    tabBar: {
        borderTopColor: 'darkgrey',
        borderTopWidth: 1 / PixelRatio.get(),
        backgroundColor: 'ghostwhite',
        opacity: 0.98
    },
    navigationBarStyle: {
        backgroundColor: 'red',
    },
    navigationBarTitleStyle: {
        color: 'white',
    },
});
export default RouterComponent;
